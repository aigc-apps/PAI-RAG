import logging
import configparser
import os

from alibabacloud_paillmtrace20240311 import models
from alibabacloud_paillmtrace20240311.client import Client
from alibabacloud_tea_openapi import models as open_api_models

from ..common import eval_constants as constants

logger = logging.getLogger(__name__)


class DataReader(object):

    def __init__(self):
        pass


class TraceDataReader(DataReader):

    def __init__(self, config_path=None):
        config = TraceDataReader._read_user_config(config_path)
        self._client = TraceDataReader.create_client(config['trace']['access_key_id'],
                                                     config['trace']['access_key_secret'], config['trace']['region'],
                                                     config['trace']['endpoint'])

    @staticmethod
    def create_client(access_key_id, access_key_secret, region, endpoint):
        config = open_api_models.Config(access_key_id=access_key_id,
                                        access_key_secret=access_key_secret,
                                        protocol='HTTPS',
                                        region_id=region,
                                        endpoint=endpoint)
        return Client(config)

    def read_data(self, max_time=None, min_time=None, page_number=None, page_size=None) -> list:
        request = models.ListTracesDatasRequest(
            max_time=max_time,
            min_time=min_time,
            page_number=page_number,
            page_size=page_size,
            opentelemetry_compatible=True,
        )
        resp = self._client.list_traces_datas(request)
        trace_list = resp.body.traces
        return trace_list

    @staticmethod
    def _read_user_config(config_path):
        config = configparser.ConfigParser()
        if not config_path:
            config_path = os.getenv(constants.CONFIG_PATH)

        with open(config_path, 'r') as cfg:
            config.read_file(cfg)

        return config

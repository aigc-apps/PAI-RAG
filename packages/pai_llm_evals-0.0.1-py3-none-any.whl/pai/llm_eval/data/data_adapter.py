import logging
from collections import defaultdict
import pandas as pd
from ..common import eval_constants as constants

logger = logging.getLogger(__name__)


class DataAdapter:
    """Base class for adapting data from data sources."""

    def __init__(self):
        # output data as the input of evaluation
        self.output_data = defaultdict(list)

    def get_retrieve_data(self) -> pd.DataFrame:
        return self.get_data(constants.SpanType.RETRIEVE)

    def get_response_data(self) -> pd.DataFrame:
        return self.get_data(constants.SpanType.LLM)

    def get_data(self, data_type: str):
        if data_type not in self.output_data:
            return None
        return pd.DataFrame(self.output_data[data_type])

    def convert(self, input_data) -> dict:
        pass

    def _update_output_data(self, input_data) -> None:
        pass

    @staticmethod
    def _validate_data(data) -> bool:
        pass

import json
import logging
from typing import List, Tuple, Union
from opentelemetry.proto.trace.v1.trace_pb2 import TracesData, Span
from google.protobuf import json_format
from ..common import eval_constants as constants
from .data_utils import base64_process_data
from .data_adapter import DataAdapter

logger = logging.getLogger(__name__)

RESOURCE_SPANS = 'resource_spans'
SCOPE_SPANS = 'scope_spans'
SPANS = 'spans'
PARENT_SPAN_ID = 'parent_span_id'
NAME = 'name'
ATTRIBUTES = 'attributes'


class TraceDataAdapter(DataAdapter):
    """Adapt data from trace service for evaluation."""

    def __init__(self):
        super().__init__()
        self.idx = 0

    def convert(self, input_data: list) -> dict:
        if not isinstance(input_data, list):
            logger.error(f'Invalid data type. Expected `list` type')
            return None

        for data in input_data:
            data = json.loads(data)

            if not TraceDataAdapter._validate_data(data):
                return None

            trace_data_list = TraceDataAdapter._parse_trace_data(data)
            self._update_output_data(trace_data_list)
        logger.info('Converted data successfully')
        return self.output_data

    def convert_trace_data(self, input_data: TracesData) -> dict:
        if not isinstance(input_data, TracesData):
            logger.error(f'Invalid data type. Expected `TracesData` type')
            return None

        trace_data_list = TraceDataAdapter._parse_trace_data_pb(input_data)
        self._update_output_data(trace_data_list)

        return self.output_data

    @staticmethod
    def _validate_data(data: Union[dict, str]) -> bool:
        if not isinstance(data, dict) and not isinstance(data, str):
            logger.error(f'Invalid data type. Expected `dict` or `str` type')
            return False

        if isinstance(data, str):
            data = json.loads(data)

        if not (resource_spans := data.get(RESOURCE_SPANS, None)):
            logger.error(f'Invalid `{RESOURCE_SPANS}`')
            return False

        for resource_span in resource_spans:
            if not (scope_spans := resource_span.get(SCOPE_SPANS, None)):
                logger.error(f'Invalid `{SCOPE_SPANS}`')
                return False

            for scope_span in scope_spans:
                if not (spans := scope_span.get(SPANS, None)):
                    logger.error(f'Invalid `{SPANS}`')
                    return False

                for span in spans:
                    if not TraceDataAdapter._validate_span_data(span):
                        logger.error(f'Invalid span data')
                        return False
        return True

    @staticmethod
    def _parse_trace_data(data: dict) -> List[Tuple[dict, dict]]:
        # parse trace data
        spans = data[RESOURCE_SPANS][0][SCOPE_SPANS][0][SPANS]
        for span in spans:
            TraceDataAdapter._process_span_data(span)
        trace_data_str = json.dumps(data)
        trace_data_pb = TraceDataAdapter._str_to_trace_pb(trace_data_str)
        return TraceDataAdapter._parse_trace_data_pb(trace_data_pb)

    @staticmethod
    def _parse_trace_data_pb(trace_data_pb: TracesData) -> List:
        trace_data = []
        for resource_span in trace_data_pb.resource_spans:
            for scope_span in resource_span.scope_spans:
                for span in scope_span.spans:
                    trace_data.append(TraceDataAdapter._parse_span_data(span))

        return trace_data

    @staticmethod
    def _str_to_trace_pb(trace_data_str: str) -> TracesData:
        traces_data = TracesData()
        json_format.Parse(trace_data_str, traces_data)
        return traces_data

    @staticmethod
    def _process_span_data(span_data: dict) -> None:
        span_data[constants.TRACE_ID] = base64_process_data(span_data[constants.TRACE_ID])
        span_data[constants.SPAN_ID] = base64_process_data(span_data[constants.SPAN_ID])
        span_data[PARENT_SPAN_ID] = base64_process_data(span_data[PARENT_SPAN_ID])

    @staticmethod
    def _parse_span_data(span_data: Span) -> Tuple[dict, dict]:
        span_dict = dict()
        # decode id attributes in span pb data
        span_dict[constants.TRACE_ID] = span_data.trace_id.decode('utf-8')
        span_dict[constants.SPAN_ID] = span_data.span_id.decode('utf-8')
        span_dict[NAME] = span_data.name
        return TraceDataAdapter._parse_span_attributes(span_data, span_dict)

    @staticmethod
    def _parse_span_attributes(span_data: dict, span_dict: dict) -> Tuple[dict, list]:
        doc_attr_list = []
        # Currently only for llm or retrieve span data
        if constants.SpanType.LLM in span_dict[NAME] or constants.SpanType.RETRIEVE in span_dict[NAME]:
            for attribute in span_data.attributes:
                attr_key = attribute.key
                attr_val = attribute.value.string_value
                if attr_key == constants.INPUT_VALUE:
                    span_dict[constants.INPUT] = attr_val
                elif attr_key == constants.OUTPUT_VALUE:
                    span_dict[constants.OUTPUT] = attr_val
                elif attr_key == constants.PROMPT_TEMPLATE_VARS:
                    prompt_var_dict = json.loads(attr_val)
                    span_dict[constants.INPUT] = prompt_var_dict.get(constants.QUERY_STR)
                    span_dict[constants.REFERENCE] = prompt_var_dict.get(constants.CONTEXT_STR)
                elif attr_key == constants.RETRIEVAL_DOCUMENTS:
                    doc_attr_arr = attribute.value.array_value
                    for doc_attrs in doc_attr_arr.values:
                        doc_attr_dict = {}
                        for doc_attr in doc_attrs.kvlist_value.values:
                            if doc_attr.key in [constants.DOCUMENT_CONTENT, constants.DOCUMENT_ID]:
                                doc_attr_dict[doc_attr.key] = doc_attr.value.string_value
                            elif doc_attr.key == constants.DOCUMENT_SCORE:
                                doc_attr_dict[doc_attr.key] = doc_attr.value.double_value
                            elif doc_attr.key == constants.VECTOR_INDEX:
                                doc_attr_dict[doc_attr.key] = doc_attr.value.int_value
                        doc_attr_list.append(doc_attr_dict)

        return span_dict, doc_attr_list

    def _update_output_data(self, trace_data: List[Tuple[dict, list]]) -> None:
        for span_dict, retrieve_doc_list in trace_data:
            if span_dict[NAME] == constants.SpanType.LLM:
                if constants.INPUT in span_dict and constants.REFERENCE in span_dict:
                    self.output_data[span_dict[NAME]].append(span_dict)
                elif constants.INPUT not in span_dict:
                    logger.warning(f'Missing `{constants.INPUT}` field in llm span data in trace')
                elif constants.REFERENCE not in span_dict:
                    logger.warning(f'Missing `{constants.REFERENCE}` field in llm span data in trace')
            elif span_dict[NAME] == constants.SpanType.RETRIEVE:
                for retrieve_doc_dict in retrieve_doc_list:
                    span_dict[constants.DOC_POS] = retrieve_doc_dict[constants.VECTOR_INDEX]
                    span_dict[constants.DOC_SCORE] = retrieve_doc_dict[constants.DOCUMENT_SCORE]
                    span_dict[constants.REFERENCE] = retrieve_doc_dict[constants.DOCUMENT_CONTENT]
                    span_dict[constants.DOC_ID] = retrieve_doc_dict[constants.DOCUMENT_ID]
                    span_dict[constants.IDX] = self.idx
                    self.output_data[span_dict[NAME]].append(span_dict.copy())
                self.idx += 1

    @staticmethod
    def _validate_span_data(data: dict) -> bool:
        if not isinstance(data, dict):
            logger.error(f'Invalid data type. Expected `dict` type')
            return False

        if not data.get(constants.TRACE_ID, None):
            logger.error(f'Invalid `{constants.TRACE_ID}`')
            return False

        if not data.get(constants.SPAN_ID, None):
            logger.error(f'Invalid `{constants.SPAN_ID}`')
            return False

        if not data.get(NAME, None):
            logger.error(f'Invalid `{NAME}`')
            return False

        if not data.get(ATTRIBUTES, None):
            logger.error(f'Invalid `{ATTRIBUTES}`')
            return False

        return True

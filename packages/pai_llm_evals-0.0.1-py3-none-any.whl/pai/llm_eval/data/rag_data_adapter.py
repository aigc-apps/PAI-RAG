import logging
from typing import List
import yaml

import pandas as pd
from ..common import eval_constants as constants
from .data_adapter import DataAdapter

logger = logging.getLogger(__name__)

QUERY = 'query'
REFERENCE_CONTEXTS = 'reference_contexts'
REFERENCE_ANSWER = 'reference_answers'
REFERENCE_NODE_IDS = 'reference_node_ids'
PREDICTED_ANSWER = 'predicted_answer'
PREDICTED_CONTEXTS = 'predicted_contexts'
PREDICTED_NODE_IDS = 'predicted_node_ids'
PREDICTED_NODE_SCORES = 'predicted_node_scores'

RAG_OFFLINE_LLM_EVAL_DATA_MAP = {
    QUERY: constants.INPUT,
    PREDICTED_ANSWER: constants.OUTPUT,
    REFERENCE_CONTEXTS: constants.REFERENCE
}

RAG_OFFLINE_RETRIEVAL_EVAL_DATA_MAP = {
    QUERY: constants.INPUT,
    PREDICTED_CONTEXTS: constants.REFERENCE,
    REFERENCE_NODE_IDS: constants.REFERENCE_ID,
    PREDICTED_NODE_IDS: constants.DOC_ID,
    PREDICTED_NODE_SCORES: constants.DOC_SCORE
}

RAG_OFFLINE_EVAL_DATA_COLS = (set(list(RAG_OFFLINE_LLM_EVAL_DATA_MAP.keys())).union(
    set(list(RAG_OFFLINE_RETRIEVAL_EVAL_DATA_MAP.keys()))))

OUTPUT_RAG_OFFLINE_RETRIEVAL_EVAL_PROCESS_COLS = [constants.REFERENCE, constants.DOC_ID, constants.DOC_SCORE]
OUTPUT_RAG_OFFLINE_LLM_EVAL_COLS = list(RAG_OFFLINE_LLM_EVAL_DATA_MAP.values())
OUTPUT_RAG_OFFLINE_RETRIEVE_EVAL_COLS = list(RAG_OFFLINE_RETRIEVAL_EVAL_DATA_MAP.values())


class RagOfflineEvalDataAdapter(DataAdapter):
    """Adapt data from rag dataset for offline evaluation."""

    def __init__(self):
        super().__init__()

    def convert(self, input_data: pd.DataFrame) -> dict:
        if not isinstance(input_data, pd.DataFrame):
            logger.error(f'Invalid data type. Expected `pd.DataFrame` type')
            return None

        if not RagOfflineEvalDataAdapter._validate_data(input_data):
            return None

        self._update_output_data(input_data)

        return self.output_data

    @staticmethod
    def _validate_data(data: pd.DataFrame) -> bool:
        cols = data.columns
        for col in RAG_OFFLINE_EVAL_DATA_COLS:
            if col not in cols:
                logger.error(f'Missing column: `{col}`')
                return False

        return True

    @staticmethod
    def _process_data(data: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
        for c in cols:
            data[c] = data[c].apply(lambda col: yaml.safe_load(str(col)))

        return data.explode(cols)

    def _update_output_data(self, input_data: pd.DataFrame) -> None:
        llm_df = input_data.rename(columns=RAG_OFFLINE_LLM_EVAL_DATA_MAP)
        llm_df = llm_df[OUTPUT_RAG_OFFLINE_LLM_EVAL_COLS]
        llm_df = llm_df.rename_axis(constants.IDX).reset_index()
        retrieval_df = input_data.rename(columns=RAG_OFFLINE_RETRIEVAL_EVAL_DATA_MAP)
        retrieval_df = retrieval_df[OUTPUT_RAG_OFFLINE_RETRIEVE_EVAL_COLS]
        retrieval_df = RagOfflineEvalDataAdapter._process_data(retrieval_df,
                                                               OUTPUT_RAG_OFFLINE_RETRIEVAL_EVAL_PROCESS_COLS)
        retrieval_df = retrieval_df.rename_axis(constants.IDX).reset_index()
        self.output_data[constants.SpanType.LLM] = llm_df.to_dict('records')
        self.output_data[constants.SpanType.RETRIEVE] = retrieval_df.to_dict('records')

import base64


def base64_process_data(data):
    bytes_data = data.encode('utf-8')
    enc_data = base64.b64encode(bytes_data)
    dec_data = enc_data.decode('utf-8')
    return dec_data


def validate_eval_data(retrieval_df, response_df) -> str:
    err_msg = ''
    if retrieval_df is None or len(retrieval_df) == 0:
        err_msg += f'Invalid retrieval data: {retrieval_df}. '
    if response_df is None or len(response_df) == 0:
        err_msg += f'Invalid response data: {response_df}.'
    return err_msg

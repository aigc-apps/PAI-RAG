import copy
import json
import logging
from typing import List, Optional
from pydantic import BaseModel, field_validator, Field, ValidationError
import pandas as pd
from ..evals.exceptions import RagEvalDataSetException, RagEvalDataValidationException

logger = logging.getLogger(__name__)


class RagEvalData(BaseModel):
    """Rag offline eval data."""
    query: Optional[str] = Field(repr=False, default=None)
    reference_contexts: Optional[List[str]] = Field(repr=False, default=None)
    reference_node_ids: Optional[List[str]] = Field(repr=False, default=None)
    reference_answer: Optional[str] = Field(repr=False, default=None)
    predicted_answer: Optional[str] = Field(repr=False, default=None)
    predicted_node_ids: Optional[List[str]] = Field(repr=False, default=None)
    predicted_contexts: Optional[List[str]] = Field(repr=False, default=None)
    predicted_node_scores: Optional[List[float]] = Field(repr=False, default=None)

    @field_validator('query')
    @classmethod
    def validate_query(cls, value: str) -> str:
        if not isinstance(value, str):
            raise RagEvalDataValidationException('Field `query` expected to be `str` type')
        return value

    @field_validator('reference_contexts')
    @classmethod
    def validate_reference_contexts(cls, value: List[str]) -> List[str]:
        if not isinstance(value, List):
            raise RagEvalDataValidationException('Field `reference_contexts` expected to be `list` type')
        return value

    @field_validator('reference_node_ids')
    @classmethod
    def validate_reference_node_ids(cls, value: List[str]) -> List[str]:
        if not isinstance(value, List):
            raise RagEvalDataValidationException('Field `reference_node_ids` expected to be `list` type')
        return value

    @field_validator('reference_answer')
    @classmethod
    def validate_reference_answer(cls, value: str) -> str:
        if not isinstance(value, str):
            raise RagEvalDataValidationException('Field `reference_answer` expected to be `str` type')
        return value

    @field_validator('predicted_answer')
    @classmethod
    def validate_predicted_answer(cls, value: str) -> str:
        if not isinstance(value, str):
            raise RagEvalDataValidationException('Field `predicted_answer` expected to be `str` type')
        return value

    @field_validator('predicted_node_ids')
    @classmethod
    def validate_predicted_node_ids(cls, value: List[str]):
        if not isinstance(value, List):
            raise RagEvalDataValidationException('Field `predicted_node_ids` expected to be `list` type')
        return value

    @field_validator('predicted_contexts')
    @classmethod
    def validate_predicted_contexts(cls, value: List[str]):
        if not isinstance(value, List):
            raise RagEvalDataValidationException('Field `predicted_contexts` expected to be `list` type')
        return value

    @field_validator('predicted_node_scores')
    @classmethod
    def validate_predicted_node_score(cls, value: List[float]):
        if not isinstance(value, List):
            raise RagEvalDataValidationException('Field `predicted_node_scores` expected to be `list` type')
        return value


class RagEvalDataSet:

    def __init__(self, file_path: str):
        self._file_path = file_path
        self._dataset = []
        self._create_dataset()
        self._df = self._create_dataframe()

    def _read_data(self):
        try:
            with open(self._file_path, 'r') as file:
                data = json.load(file)
        except json.JSONDecodeError:
            err_msg = f'Invalid json file: {self._file_path}'
            logger.error(err_msg, exc_info=True)
            raise RagEvalDataSetException(err_msg)
        except FileNotFoundError:
            err_msg = f'File not found: {self._file_path}'
            logger.error(err_msg, exc_info=True)
            raise RagEvalDataSetException(err_msg)

        try:
            data_dict = data['examples']
            return data_dict
        except KeyError:
            err_msg = 'Missing `examples` key in json data'
            logger.error(err_msg, exc_info=True)
            raise RagEvalDataSetException(err_msg)

    def _create_dataset(self):
        data_dict = self._read_data()
        for d in data_dict:
            try:
                self._dataset.append(RagEvalData.parse_obj(d))
            except ValidationError as e:
                err_msg = f'Fail to create rag eval dataset: {e}'
                logger.error(err_msg, exc_info=True)
                raise RagEvalDataSetException(err_msg)

    def _create_dataframe(self) -> pd.DataFrame:
        if not self._dataset:
            raise RagEvalDataSetException('Empty data set')
        return pd.DataFrame([data.__dict__ for data in self._dataset])

    def get_dataset(self) -> List[RagEvalData]:
        return copy.deepcopy(self._dataset)

    def get_df(self) -> pd.DataFrame:
        return copy.deepcopy(self._df)


if __name__ == "__main__":
    rag_ds = RagEvalDataSet(file_path='../../../../notebook/data/qca_dataset.json')
    df = rag_ds.get_df()
    print(df)

import logging
import re
from dataclasses import dataclass
from typing import Callable, Dict, List, Mapping, Optional, Tuple, Union

from .exceptions import LLMEvalException
from ..common import eval_constants as constants

logger = logging.getLogger(__name__)


@dataclass
class PromptOptions:
    provide_explanation: bool = False


class InvalidClassificationTemplateError(LLMEvalException):
    pass


class PromptTemplate:

    def __init__(
            self,
            template: str,
            delimiters: Tuple[str, str] = (constants.DEFAULT_START_DELIM, constants.DEFAULT_END_DELIM),
    ):
        self.template = template
        self._start_delim, self._end_delim = delimiters
        self.pattern = re.escape(self._start_delim) + "(.*?)" + re.escape(self._end_delim)
        self.variables = self._parse_variables(self.template)

    def prompt(self, options: Optional[PromptOptions] = None) -> str:
        # pylint: disable=unused-argument
        return self.template

    def format(
        self,
        variable_values: Mapping[str, Union[bool, int, float, str]],
        options: Optional[PromptOptions] = None,
    ) -> str:
        prompt = self.prompt(options)
        for variable_name in self.variables:
            prompt = prompt.replace(
                self._start_delim + variable_name + self._end_delim,
                str(variable_values[variable_name]),
            )
        return prompt

    def _parse_variables(self, text: str) -> List[str]:
        variables = re.findall(self.pattern, text)
        return variables


class ClassificationTemplate(PromptTemplate):

    def __init__(
        self,
        rails: List[str],
        template: str,
        explanation_template: Optional[str] = None,
        explanation_label_parser: Optional[Callable[[str], str]] = None,
        delimiters: Tuple[str, str] = (constants.DEFAULT_START_DELIM, constants.DEFAULT_END_DELIM),
        scores: Optional[List[float]] = None,
        metric_name: Optional[str] = None,
    ):
        super().__init__(template, delimiters)
        if scores is not None and len(rails) != len(scores):
            raise InvalidClassificationTemplateError(
                "If scores are provided, each rail must have one and only one score "
                "(i.e., the length of both lists must be the same).")
        self.rails = rails
        self.explanation_template = explanation_template
        self.explanation_label_parser = explanation_label_parser
        self.variables: List[str] = []
        for text in [template, explanation_template]:
            if text is not None:
                self.variables += self._parse_variables(text)
        self._scores = scores
        self.metric_name = metric_name

    def __repr__(self) -> str:
        return self.template

    def prompt(self, options: Optional[PromptOptions] = None) -> str:
        if options is None:
            return self.template

        if options.provide_explanation and self.explanation_template:
            return self.explanation_template
        else:
            return self.template

    def extract_label_from_explanation(self, raw_string: str) -> str:
        if parser := self.explanation_label_parser:
            return parser(raw_string)
        return self.parse_label_from_chain_of_thought_response(raw_string)

    def parse_label_from_chain_of_thought_response(self, raw_string: str) -> str:
        try:
            data = eval(raw_string)
            return data['label']
        except (SyntaxError, NameError):
            logging.warning('Invalid json format, parse the string')
            label_delimiter = r"\W*label\W*"
            parts = re.split(label_delimiter, raw_string, maxsplit=1, flags=re.IGNORECASE)
            if len(parts) == 2:
                return parts[1]
        return constants.INVALID

    def score(self, rail: str) -> float:
        if self._scores is None:
            return 0.0
        try:
            return self._scores[self.rails.index(rail)]
        except (IndexError, ValueError):
            return 0.0


class CustomClassificationTemplate(ClassificationTemplate):

    def __init__(
        self,
        rail_maps: List[Dict[str, int]],
        template: str,
        explanation_template: Optional[str] = None,
        explanation_label_parser: Optional[Callable[[str], str]] = None,
        delimiters: Tuple[str, str] = (constants.DEFAULT_START_DELIM, constants.DEFAULT_END_DELIM),
        metrics: Optional[List[str]] = None,
    ):
        self.template = template
        self.explanation_template = explanation_template
        if not self.is_substr():
            self.explanation_template = self.template + self.explanation_template
        metric_name = ','.join(metrics) if metrics else ''

        super().__init__(rails=[key for r in rail_maps for key in r.keys()],
                         template=template,
                         explanation_template=explanation_template,
                         explanation_label_parser=explanation_label_parser,
                         delimiters=delimiters,
                         scores=[val for r in rail_maps for val in r.values()],
                         metric_name=metric_name)

    def is_substr(self):
        if not self.template or not self.explanation_template:
            return True

        return self.template in self.explanation_template

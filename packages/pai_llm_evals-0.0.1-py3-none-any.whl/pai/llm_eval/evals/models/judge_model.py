import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
import os
from ai_service_python_sdk.client import ApiClient
from ai_service_python_sdk.client.api.ai_service_llm_api import AiServiceLlmApi

from ...common import eval_constants as constants
from .base_model import BaseModel

# pylint: disable = E1125,W0201
logger = logging.getLogger(__name__)


@dataclass
class JudgeModel(BaseModel):
    # judge model API config
    api_key: Optional[str] = field(repr=False, default=None)
    # host for judge model API
    host: Optional[str] = field(repr=False, default=None)
    # app id
    app_id: Optional[str] = field(repr=False, default=None)
    # judge model name. Default: Themis-1.0
    model: str = "Themis-1.0"

    def __post_init__(self):
        self._init_model()

    def _init_model(self) -> None:
        self._check_api_key()

    def _check_api_key(self):
        if self.api_key is None:
            api_key = os.getenv(constants.THEMIS_API_KEY)
            if api_key is None:
                raise RuntimeError("THEMIS model API key not provided. Config 'api_key' "
                                   "or set in your environment: 'export THEMIS_API_KEY=****'")
            self.api_key = api_key

    def reload_client(self) -> None:
        self._init_model()

    def _generate(self, prompt: str, **kwargs: Any) -> str:
        invoke_params = self.invocation_params
        messages = self._build_messages(prompt, kwargs.get("instruction"))
        client = ApiClient(self.host, self.app_id, self.api_key)
        response = AiServiceLlmApi(client).llm_evaluation.create(
            messages=messages,
            **invoke_params,
        )
        choice = response.data['choices'][0]
        return str(choice["text"])

    def _async_generate(self, prompt: str, **kwargs: Any) -> str:
        # ToDo: currently judge model SDK does not support async mode, will update after building pop API/SDK
        pass

    @property
    def invocation_params(self) -> Dict[str, Any]:
        return {
            **({
                "model": self.model
            }),
            **self._default_params,
        }

    @property
    def _default_params(self) -> Dict[str, Any]:
        """Get the default parameters for Judge model API."""
        # ToDo: discuss with judge model dev team for further improvement
        return {}

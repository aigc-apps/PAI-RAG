import logging
from dataclasses import dataclass, field
from typing import (Any, Dict, Optional, Tuple, Union)
import os
import warnings
import openai

from ...common import eval_constants as constants
from ..exceptions import LLMEvalContextLimitExceeded
from .base_model import BaseModel

# pylint: disable = E1125,W0201
logger = logging.getLogger(__name__)
warnings.filterwarnings("ignore", category=UserWarning)


@dataclass
class OpenAIModel(BaseModel):
    # OpenAI key
    api_key: Optional[str] = field(repr=False, default=None)
    # Organization to use for OpenAI API
    organization: Optional[str] = field(repr=False, default=None)
    # Base url to use for OpenAI API
    base_url: Optional[str] = field(repr=False, default=None)
    # OpenAI model name. Default: gpt-4
    model: str = "gpt-4"
    # Control the randomness and creativity of the responses
    temperature: float = 1.0
    # Max limit of tokens to generate
    max_tokens: int = 256
    # Total probability of tokens to consider
    top_p: float = 1
    # Penalize the repeated tokens based on frequency
    frequency_penalty: float = 0
    # Penalize the repeated tokens based on presence
    presence_penalty: float = 0
    # Number of completions to generate for each prompt
    n: int = 1
    model_kwargs: Dict[str, Any] = field(default_factory=dict)
    batch_size: int = 20
    # Request timeout for OpenAI API
    request_timeout: Optional[Union[float, Tuple[float, float]]] = None

    def __post_init__(self) -> None:
        self._init_environment()
        self._init_open_ai()

    def _init_environment(self) -> None:
        try:
            self._openai = openai
        except ImportError:
            BaseModel._raise_import_error(
                package_display_name="OpenAI",
                package_name="openai",
                package_min_version=constants.OPENAI_MINIMUM_VERSION,
            )

    def _init_open_ai(self) -> None:
        self._model_uses_legacy_completion_api = self.model.startswith(constants.OPENAI_LEGACY_COMPLETION_API_MODELS)
        self._check_api_key()
        self.organization = self.organization or self._openai.organization
        self._create_client()

    def _check_api_key(self):
        if self.api_key is None:
            api_key = os.getenv(constants.OPENAI_API_KEY)
            if api_key is None:
                raise RuntimeError("OpenAI's API key not provided. Config 'api_key' "
                                   "or set in your environment: 'export OPENAI_API_KEY=sk-****'")
            self.api_key = api_key

    def _create_client(self):

        self._client = self._openai.OpenAI(
            api_key=self.api_key,
            organization=self.organization,
            base_url=(self.base_url or self._openai.base_url),
        )

        self._async_client = self._openai.AsyncOpenAI(
            api_key=self.api_key,
            organization=self.organization,
            base_url=(self.base_url or self._openai.base_url),
            max_retries=0,
        )

    def reload_client(self) -> None:
        self._init_open_ai()

    async def _async_generate(self, prompt: str, **kwargs: Any) -> str:
        invoke_params = self.invocation_params
        messages = self._build_messages(prompt, kwargs.get("instruction"))
        if functions := kwargs.get(constants.TOOLS):
            invoke_params[constants.TOOLS] = functions
        if function_call := kwargs.get(constants.TOOL_CHOICE):
            invoke_params[constants.TOOL_CHOICE] = function_call
        response = await self._async_completion(
            messages=messages,
            **invoke_params,
        )
        choice = response["choices"][0]
        if self._model_uses_legacy_completion_api:
            return str(choice["text"])
        message = choice["message"]
        if tool_calls := message.get("tool_calls"):
            for tool_call in tool_calls:
                if (tool_call.get('type') == constants.FUNCTION
                        and tool_call[constants.FUNCTION]['name'] == constants.FUNCTION_NAME):
                    return str(tool_call[constants.FUNCTION].get("arguments") or "")
        return str(message["content"])

    def _generate(self, prompt: str, **kwargs: Any) -> str:
        invoke_params = self.invocation_params
        messages = self._build_messages(prompt, kwargs.get("instruction"))
        if functions := kwargs.get(constants.TOOLS):
            invoke_params[constants.TOOLS] = functions
        if function_call := kwargs.get(constants.TOOL_CHOICE):
            invoke_params[constants.TOOL_CHOICE] = function_call
        response = self._completion(
            messages=messages,
            **invoke_params,
        )
        choice = response["choices"][0]
        if self._model_uses_legacy_completion_api:
            return str(choice["text"])
        message = choice["message"]
        if tool_calls := message.get("tool_calls"):
            for tool_call in tool_calls:
                if (tool_call.get('type') == constants.FUNCTION
                        and tool_call[constants.FUNCTION]['name'] == constants.FUNCTION_NAME):
                    return str(tool_call[constants.FUNCTION].get("arguments") or "")
        return str(message["content"])

    async def _async_completion(self, **kwargs: Any) -> Any:
        try:
            if self._model_uses_legacy_completion_api:
                if "prompt" not in kwargs:
                    kwargs["prompt"] = "\n\n".join(
                        (message.get("content") or "") for message in (kwargs.pop("messages", None) or ()))

                res = await self._async_client.completions.create(**kwargs)
            else:
                res = await self._async_client.chat.completions.create(**kwargs)
            return res.model_dump()
        except self._openai._exceptions.BadRequestError as e:
            exception_message = e.args[0]
            if exception_message and "maximum context length" in exception_message:
                raise LLMEvalContextLimitExceeded(exception_message) from e
            raise e

    def _completion(self, **kwargs: Any) -> Any:
        try:
            if self._model_uses_legacy_completion_api:
                if "prompt" not in kwargs:
                    kwargs["prompt"] = "\n\n".join(
                        (message.get("content") or "") for message in (kwargs.pop("messages", None) or ()))

                return self._client.completions.create(**kwargs).model_dump()
            return self._client.chat.completions.create(**kwargs).model_dump()
        except self._openai._exceptions.BadRequestError as e:
            exception_message = e.args[0]
            if exception_message and "maximum context length" in exception_message:
                raise LLMEvalContextLimitExceeded(exception_message) from e
            raise e

    @property
    def public_invocation_params(self) -> Dict[str, Any]:
        return {
            **({
                "model": self.model
            }),
            **self._default_params,
            **self.model_kwargs,
        }

    @property
    def invocation_params(self) -> Dict[str, Any]:
        return {
            **self.public_invocation_params,
        }

    @property
    def _default_params(self) -> Dict[str, Any]:
        """Get the default parameters for OpenAI API."""
        return {
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "frequency_penalty": self.frequency_penalty,
            "presence_penalty": self.presence_penalty,
            "top_p": self.top_p,
            "n": self.n,
            "timeout": self.request_timeout,
        }

    @property
    def supports_function_calling(self) -> bool:
        return not self._model_uses_legacy_completion_api

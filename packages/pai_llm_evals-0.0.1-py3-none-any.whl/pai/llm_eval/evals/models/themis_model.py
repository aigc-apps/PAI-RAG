import logging
import os
from dataclasses import dataclass, field
from typing import Optional

from ...common import eval_constants as constants
from .openai_model import OpenAIModel

logger = logging.getLogger(__name__)


@dataclass
class ThemisModel(OpenAIModel):
    # Base url to use for themis API
    base_url: Optional[str] = field(repr=False, default=constants.THEMIS_BASE_URL)
    # model name. Default: Themis-turbo
    model: str = "Themis-turbo"

    def _check_api_key(self):
        if self.api_key is None:
            api_key = os.getenv(constants.THEMIS_API_KEY)
            if api_key is None:
                raise RuntimeError("THEMIS API key not provided. Config 'api_key' "
                                   "or set in your environment: 'export THEMIS_API_KEY=sk-****'")
            self.api_key = api_key

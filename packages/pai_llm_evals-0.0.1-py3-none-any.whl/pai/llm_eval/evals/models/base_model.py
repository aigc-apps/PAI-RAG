import logging
from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Any, Dict, List, Generator, Optional

logger = logging.getLogger(__name__)


class BaseModel(ABC):
    _verbose: bool = False

    def __call__(self, prompt: str, instruction: Optional[str] = None, **kwargs: Any) -> str:
        """Run LLM on the given prompt."""
        if not isinstance(prompt, str):
            raise TypeError("Invalid prompt type. Expected a string but found "
                            f"{type(prompt)}. To run the LLM on multiple prompts, use "
                            "`generate` instead.")
        if instruction is not None and not isinstance(instruction, str):
            raise TypeError("Invalid type for argument `instruction`. Expected a string but found "
                            f"{type(instruction)}.")
        return self._generate(prompt=prompt, instruction=instruction, **kwargs)

    def reload_client(self) -> None:
        pass

    @abstractmethod
    async def _async_generate(self, prompt: str, **kwargs: Any) -> str:
        raise NotImplementedError

    @abstractmethod
    def _generate(self, prompt: str, **kwargs: Any) -> str:
        raise NotImplementedError

    @staticmethod
    def _raise_import_error(package_name: str, package_display_name: str = "", package_min_version: str = "") -> None:
        if not package_display_name:
            package_display_name = package_name
        msg = (f"Failed to import necessary dependencies to use {package_display_name}. "
               "Please run ")
        if package_min_version:
            msg += f"`pip install {package_name}>={package_min_version}`."
        else:
            msg += f"`pip install {package_name}`."
        raise ImportError(msg)

    @staticmethod
    def _build_messages(prompt: str, system_instruction: Optional[str] = None) -> List[Dict[str, str]]:
        messages = [{"role": "user", "content": prompt}]
        if system_instruction:
            messages.insert(0, {"role": "system", "content": str(system_instruction)})
        return messages


@contextmanager
def set_verbosity(model: "BaseModel", verbose: bool = False) -> Generator["BaseModel", None, None]:
    model._verbose = verbose
    yield model

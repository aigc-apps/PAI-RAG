from collections import OrderedDict
from enum import Enum

from .templates import ClassificationTemplate
from ..common import eval_constants as constants


class DefaultPromptRailsMap:
    RETRIEVER_RELEVANCE_PROMPT_RAILS_MAP = OrderedDict({True: "relevant", False: "unrelated"})
    FAITHFULNESS_PROMPT_RAILS_MAP = OrderedDict({True: "factual", False: "hallucinated"})
    RAG_CORRECTNESS_PROMPT_RAILS_MAP = OrderedDict({True: "correct", False: "incorrect"})


class DefaultPromptRailsMapCN:
    RETRIEVER_RELEVANCE_PROMPT_RAILS_MAP = OrderedDict({True: "相关", False: "不相关"})
    FAITHFULNESS_PROMPT_RAILS_MAP = OrderedDict({True: "事实", False: "幻觉"})
    RAG_CORRECTNESS_PROMPT_RAILS_MAP = OrderedDict({True: "正确", False: "不正确"})


class DefaultPromptTemplate:
    RETRIEVER_RELEVANCE_PROMPT_BASE_TEMPLATE = """
    You are comparing a reference text to a question and trying to determine if the reference text
    contains information relevant to answering the question. Here is the data:
        [BEGIN DATA]
        ************
        [Question]: {{input}}
        ************
        [Reference text]: {{reference}}
        ************
        [END DATA]
    Compare the Question above to the Reference text. You must determine whether the Reference text
    contains information that can answer the Question. Please focus on whether the very specific
    question can be answered by the information in the Reference text.
    Your response must be single word, either "relevant" or "unrelated",
    and should not contain any text or characters aside from that word.
    "unrelated" means that the reference text does not contain an answer to the Question.
    "relevant" means the reference text contains an answer to the Question.

    Think carefully for a while and then come to your conclusion. What you return is a json data structure
    containing the following fields: label.
    The format is as follows: {"label": "<label>"}
    """

    RETRIEVER_RELEVANCE_PROMPT_TEMPLATE_WITH_EXPLANATION = """
    You are comparing a reference text to a question and trying to determine if the reference text
    contains information relevant to answering the question. Here is the data:

        [BEGIN DATA]
        ************
        [Question]: {{input}}
        ************
        [Reference text]: {{reference}}
        ************
        [END DATA]

    Compare the Question above to the Reference text. You must determine whether the Reference text
    contains information that can help answer the Question. First, write out in a step by step manner
    an EXPLANATION to show how to arrive at the correct answer. Avoid simply stating the correct answer
    at the outset. Your response LABEL must be single word, either "relevant" or "unrelated", and
    should not contain any text or characters aside from that word. "unrelated" means that the
    reference text does not help answer to the Question. "relevant" means the reference text directly
    answers the question.

    Think carefully for a while and then come to your conclusion. What you return is a json data structure
    containing the following fields: label and reason.
    The format is as follows: {"label": "<label>", "reason": "<reason>"}
    """

    FAITHFULNESS_PROMPT_BASE_TEMPLATE = """
    In this task, you will be presented with a query, a reference text and an answer. The answer is
    generated to the question based on the reference text. The answer may contain false information, you
    must use the reference text to determine if the answer to the question contains false information,
    if the answer is a hallucination of facts. Your objective is to determine whether the reference text
    contains factual information and is not a hallucination. A 'hallucination' in this context refers to
    an answer that is not based on the reference text or assumes information that is not available in
    the reference text. Your response should be a single word: either "factual" or "hallucinated", and
    it should not include any other text or characters. "hallucinated" indicates that the answer
    provides factually inaccurate information to the query based on the reference text. "factual"
    indicates that the answer to the question is correct relative to the reference text, and does not
    contain made up information. Please read the query and reference text carefully before determining
    your response.

        [BEGIN DATA]
        ************
        [Query]: {{input}}
        ************
        [Reference text]: {{reference}}
        ************
        [Answer]: {{output}}
        ************
        [END DATA]

        Is the answer above factual or hallucinated based on the query and reference text?

    Think carefully for a while and then come to your conclusion. What you return is a json data structure
    containing the following fields: label.
    The format is as follows: {"label": "<label>"}
    """

    FAITHFULNESS_PROMPT_TEMPLATE_WITH_EXPLANATION = """
    In this task, you will be presented with a query, a reference text and an answer. The answer is
    generated to the question based on the reference text. The answer may contain false information, you
    must use the reference text to determine if the answer to the question contains false information,
    if the answer is a hallucination of facts. Your objective is to determine whether the reference text
    contains factual information and is not a hallucination. A 'hallucination' in this context refers to
    an answer that is not based on the reference text or assumes information that is not available in
    the reference text.

        [BEGIN DATA]
        ************
        [Query]: {{input}}
        ************
        [Reference text]: {{reference}}
        ************
        [Answer]: {{output}}
        ************
        [END DATA]

        Is the answer above factual or hallucinated based on the query and reference text?

    Please read the query, reference text and answer carefully, then write out in a step by step manner
    an EXPLANATION to show how to determine if the answer is "factual" or "hallucinated". Avoid simply
    stating the correct answer at the outset. Your response LABEL should be a single word: either
    "factual" or "hallucinated", and it should not include any other text or characters. "hallucinated"
    indicates that the answer provides factually inaccurate information to the query based on the
    reference text. "factual" indicates that the answer to the question is correct relative to the
    reference text, and does not contain made up information.

    Think carefully for a while and then come to your conclusion. What you return is a json data structure
    containing the following fields: label and reason.
    The format is as follows: {"label": "<label>", "reason": "<reason>"}
    """

    RAG_CORRECTNESS_PROMPT_BASE_TEMPLATE = """
    You are given a question, an answer and reference text. You must determine whether the
    given answer correctly answers the question based on the reference text. Here is the data:

        [BEGIN DATA]
        ************
        [Question]: {{input}}
        ************
        [Reference]: {{reference}}
        ************
        [Answer]: {{output}}
        [END DATA]

    Your response must be a single word, either "correct" or "incorrect",
    and should not contain any text or characters aside from that word.
    "correct" means that the question is correctly and fully answered by the answer.
    "incorrect" means that the question is not correctly or only partially answered by the
    answer.

    Think carefully for a while and then come to your conclusion. What you return is a json data structure 
    containing the following fields: label.
    The format is as follows: {"label": "<label>"}
    """

    RAG_CORRECTNESS_PROMPT_TEMPLATE_WITH_EXPLANATION = """
    You are given a question, an answer and reference text. You must determine whether the
    given answer correctly answers the question based on the reference text. Here is the data:
        [BEGIN DATA]
        ************
        [Question]: {{input}}
        ************
        [Reference]: {{reference}}
        ************
        [Answer]: {{output}}
        [END DATA]
    Please read the query, reference text and answer carefully, then write out in a step by step manner
    an EXPLANATION to show how to determine if the answer is "correct" or "incorrect". Avoid simply
    stating the correct answer at the outset. Your response LABEL must be a single word, either
    "correct" or "incorrect", and should not contain any text or characters aside from that word.
    "correct" means that the question is correctly and fully answered by the answer.
    "incorrect" means that the question is not correctly or only partially answered by the
    answer.

    Think carefully for a while and then come to your conclusion. What you return is a json data structure
    containing the following fields: label and reason.
    The format is as follows: {"label": "<label>", "reason": "<reason>"}
    """

    RETRIEVER_RELEVANCE_PROMPT_TEMPLATE = ClassificationTemplate(
        rails=list(DefaultPromptRailsMap.RETRIEVER_RELEVANCE_PROMPT_RAILS_MAP.values()),
        template=RETRIEVER_RELEVANCE_PROMPT_BASE_TEMPLATE,
        explanation_template=RETRIEVER_RELEVANCE_PROMPT_TEMPLATE_WITH_EXPLANATION,
        scores=[1, 0],
        metric_name=constants.RETRIEVER_RELEVANCE,
    )

    FAITHFULNESS_PROMPT_TEMPLATE = ClassificationTemplate(
        rails=list(DefaultPromptRailsMap.FAITHFULNESS_PROMPT_RAILS_MAP.values()),
        template=FAITHFULNESS_PROMPT_BASE_TEMPLATE,
        explanation_template=FAITHFULNESS_PROMPT_TEMPLATE_WITH_EXPLANATION,
        scores=[1, 0],
        metric_name=constants.FAITHFULNESS,
    )

    RAG_CORRECTNESS_PROMPT_TEMPLATE = ClassificationTemplate(
        rails=list(DefaultPromptRailsMap.RAG_CORRECTNESS_PROMPT_RAILS_MAP.values()),
        template=RAG_CORRECTNESS_PROMPT_BASE_TEMPLATE,
        explanation_template=RAG_CORRECTNESS_PROMPT_TEMPLATE_WITH_EXPLANATION,
        scores=[1, 0],
        metric_name=constants.RAG_CORRECTNESS,
    )


class DefaultPromptTemplateCN:
    RETRIEVER_RELEVANCE_PROMPT_BASE_TEMPLATE = """
    您正在将参考文本与问题进行比较，并尝试确定参考文本是否包含与回答问题相关的信息。这是数据：
        [开始数据]
        **********
        [问题]：{{input}}
        **********
        [参考文字]：{{reference}}
        **********
        [数据结束]
    将上面的问题与参考文本进行比较。您必须确定参考文本是否包含可以回答问题的信息。请重点关注是否非常具体
    问题可以通过参考文本中的信息来回答。您的回答必须是单个词，“相关”或“无关”，并且不应包含除该单词之外的任何文本或字符。
    “不相关”意味着参考文本不包含问题的答案。“相关”是指参考文本包含问题的答案。

    仔细思考一会，然后给出你的结论。你返回的内容是一个json数据结构，包含以下字段："label"。
    格式如下：{"label": "<标签>""}
    """

    RETRIEVER_RELEVANCE_PROMPT_TEMPLATE_WITH_EXPLANATION = """
    您正在将参考文本与问题进行比较，并尝试确定参考文本是否包含与回答问题相关的信息。这是数据：
            [开始数据]
            **********
            [问题]：{{input}}
            **********
            [参考文字]：{{reference}}
            **********
            [数据结束]
        将上面的问题与参考文本进行比较。您必须确定参考文本是否包含可以帮助回答问题的信息。首先一步步写出来
        说明如何得出正确答案。避免简单地陈述正确答案一开始。您的回复标签必须是单个单词，“相关”或“不相关”，并且
        除该单词外不应包含任何文本或字符。 “不相关”意味着参考文本无助于回答问题。 “相关”是指直接参考文本
        回答了问题。

        仔细思考一会，然后给出你的结论。你返回的内容是一个json数据结构，其中包含以下字段："label"，"reason"，
        返回格式如下：{"label":"<标签>", "reason":"<理由>"}
    """

    FAITHFULNESS_PROMPT_BASE_TEMPLATE = """
    在此任务中，您将看到一个查询、参考文本和答案。答案是根据参考文本生成问题。答案可能包含虚假信息，您
    必须使用参考文本来确定问题的答案是否包含虚假信息，如果答案是事实的幻觉。您的目标是确定参考文本是否
    包含事实信息，并非幻觉。本文中的“幻觉”是指答案不是基于参考文本或假设的信息不可用参考文本。您的回答
    应该是一个词：“事实”或“幻觉”，并且它不应包含任何其他文本或字符。 “幻觉”表明答案根据参考文本向查询
    提供实际上不准确的信息。 “事实”表示问题的答案相对于参考文本是正确的，而不是包含虚构的信息。确定前
    请仔细阅读查询及参考文字你的回应。

        [开始数据]
        **********
        [查询]：{{input}}
        **********
        [参考文字]：{{reference}}
        **********
        [答案]：{{output}}
        **********
        [数据结束]

        根据查询和参考文本，上述答案是事实还是幻觉？

    仔细思考一会，然后给出你的结论。你返回的内容是一个json数据结构，包含以下字段："label"。
    格式如下：{"label": "<标签>""}
    """

    FAITHFULNESS_PROMPT_TEMPLATE_WITH_EXPLANATION = """
    在此任务中，您将看到一个查询、参考文本和答案。答案是根据参考文本生成问题。答案可能包含虚假信息，您
    必须使用参考文本来确定问题的答案是否包含虚假信息，如果答案是事实的幻觉。您的目标是确定参考文本是否
    包含事实信息，并非幻觉。本文中的“幻觉”是指答案不是基于参考文本或假设的信息不可用参考文本。

        [开始数据]
        **********
        [查询]：{{input}}
        **********
        [参考文字]：{{reference}}
        **********
        [答案]：{{output}}
        **********
        [数据结束]

        根据查询和参考文本，上述答案是事实还是幻觉？

    请仔细阅读查询、参考文本和答案，然后逐步写出说明如何确定答案是“事实”还是“幻觉”。简单地避免
    一开始就说出正确答案。您的回复标签应该是一个单词：要么“事实”或“幻觉”，并且不应包含任何其他
    文本或字符。 “产生幻觉”表示答案向基于查询的查询提供了事实上不准确的信息参考文本。 “事实”表
    明问题的答案相对于事实是正确的参考文本，不包含虚构信息。

    仔细思考一会，然后给出你的结论。你返回的内容是一个json数据结构，其中包含以下字段："label"，"reason"。
    返回格式如下：{"label":"<标签>", "reason":"<理由>"}
    """

    RAG_CORRECTNESS_PROMPT_BASE_TEMPLATE = """
    您将收到一个问题、一个答案和参考文本。您必须确定是否给出的答案根据参考文本正确回答了问题。这是数据：

        [开始数据]
        **********
        [问题]：{{input}}
        **********
        [参考]：{{reference}}
        **********
        [答案]：{{output}}
        [数据结束]

    您的回答必须是一个单词，“正确”或“不正确”，并且不应包含除该单词之外的任何文本或字符。
    “正确”是指问题的答案是正确且完整的。“不正确”是指问题没有正确回答或者只回答了部分问题
    回答。

    仔细思考一会，然后给出你的结论。你返回的内容是一个json数据结构，包含以下字段："label"。
    格式如下：{"label": "<标签>""}
    """

    RAG_CORRECTNESS_PROMPT_TEMPLATE_WITH_EXPLANATION = """
    您将收到一个问题、一个答案和参考文本。您必须确定是否给出的答案根据参考文本正确回答了问题。这是数据：
        [开始数据]
        **********
        [问题]：{{input}}
        **********
        [参考]：{{reference}}
        **********
        [答案]：{{output}}
        [数据结束]
    请仔细阅读查询、参考文本和答案，然后逐步写出说明如何确定答案是“正确”还是“不正确”。简单地避免一开始就
    说出正确答案。您的回复标签必须是一个单词“正确”或“不正确”，并且不应包含除该单词之外的任何文本或字符。
    “正确”是指问题的答案是正确且完整的。“不正确”是指问题没有正确回答或者只回答了部分问题回答。

    仔细思考一会，然后给出你的结论。你返回的内容是一个json数据结构，其中包含以下字段："label"，"reason"。
    返回格式如下：{"label":"<标签>", "reason":"<理由>"}
    """

    RETRIEVER_RELEVANCE_PROMPT_TEMPLATE = ClassificationTemplate(
        rails=list(DefaultPromptRailsMapCN.RETRIEVER_RELEVANCE_PROMPT_RAILS_MAP.values()),
        template=RETRIEVER_RELEVANCE_PROMPT_BASE_TEMPLATE,
        explanation_template=RETRIEVER_RELEVANCE_PROMPT_TEMPLATE_WITH_EXPLANATION,
        scores=[1, 0],
        metric_name=constants.RETRIEVER_RELEVANCE,
    )

    FAITHFULNESS_PROMPT_TEMPLATE = ClassificationTemplate(
        rails=list(DefaultPromptRailsMapCN.FAITHFULNESS_PROMPT_RAILS_MAP.values()),
        template=FAITHFULNESS_PROMPT_BASE_TEMPLATE,
        explanation_template=FAITHFULNESS_PROMPT_TEMPLATE_WITH_EXPLANATION,
        scores=[1, 0],
        metric_name=constants.FAITHFULNESS,
    )

    RAG_CORRECTNESS_PROMPT_TEMPLATE = ClassificationTemplate(
        rails=list(DefaultPromptRailsMapCN.RAG_CORRECTNESS_PROMPT_RAILS_MAP.values()),
        template=RAG_CORRECTNESS_PROMPT_BASE_TEMPLATE,
        explanation_template=RAG_CORRECTNESS_PROMPT_TEMPLATE_WITH_EXPLANATION,
        scores=[1, 0],
        metric_name=constants.RAG_CORRECTNESS,
    )


class EvalCriteria(Enum):
    RETRIEVER_RELEVANCE = DefaultPromptTemplate.RETRIEVER_RELEVANCE_PROMPT_TEMPLATE
    FAITHFULNESS = DefaultPromptTemplate.FAITHFULNESS_PROMPT_TEMPLATE
    RAG_CORRECTNESS = DefaultPromptTemplate.RAG_CORRECTNESS_PROMPT_TEMPLATE

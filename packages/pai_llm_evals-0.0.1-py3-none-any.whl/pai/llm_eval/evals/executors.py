from __future__ import annotations

import asyncio
import logging
import signal
import traceback

from collections import defaultdict
from itertools import product
from typing import (
    Any,
    Callable,
    Coroutine,
    DefaultDict,
    Dict,
    List,
    Mapping,
    NamedTuple,
    Optional,
    Protocol,
    Sequence,
    Tuple,
    Union,
)

from pandas import DataFrame
from typing_extensions import TypeAlias
from ..common import eval_constants as constants
from .exceptions import LLMEvalException
from .evaluators import LLMEvaluator

logger = logging.getLogger(__name__)
ColumnName: TypeAlias = str
Label: TypeAlias = str
Score: TypeAlias = Optional[float]
Explanation: TypeAlias = Optional[str]
Record: TypeAlias = Mapping[str, Any]
Index: TypeAlias = int


class Executor(Protocol):

    def run(self, inputs: Sequence[Any]) -> List[Any]:
        pass


class AsyncExecutor(Executor):
    """Asynchronous execution of tasks."""

    def __init__(
        self,
        generation_fn: Callable[[Any], Coroutine[Any, Any, Any]],
        concurrency: int = 3,
        max_retries: int = 10,
        exit_on_error: bool = True,
        fallback_return_value: Union[Any, Any] = None,
        termination_signal: signal.Signals = signal.SIGINT,
    ):
        self.generate = generation_fn
        self.fallback_return_value = fallback_return_value
        self.concurrency = concurrency
        self.max_retries = max_retries
        self.exit_on_error = exit_on_error
        self.base_priority = 0
        self.termination_signal = termination_signal

    async def producer(
        self,
        inputs: Sequence[Any],
        queue: asyncio.PriorityQueue[Tuple[int, Any]],
        max_fill: int,
        done_producing: asyncio.Event,
        termination_signal: asyncio.Event,
    ) -> None:
        try:
            for idx, input in enumerate(inputs):
                if termination_signal.is_set():
                    break
                while queue.qsize() >= max_fill:
                    await asyncio.sleep(1)
                await queue.put((self.base_priority, (idx, input)))
        finally:
            done_producing.set()

    async def consumer(
        self,
        output: List[Any],
        queue: asyncio.PriorityQueue[Tuple[int, Any]],
        done_producing: asyncio.Event,
        termination_event: asyncio.Event,
    ) -> None:
        termination_event_watcher = None
        while True:
            marked_done = False
            try:
                priority, item = await asyncio.wait_for(queue.get(), timeout=1)
            except asyncio.TimeoutError:
                if done_producing.is_set() and queue.empty():
                    # make sure the queue is empty before exiting the loop
                    break
                continue
            if termination_event.is_set():
                # clear all the items in the queue
                queue.task_done()
                # need to check if any new item is enqueuing
                continue

            idx, payload = item
            try:
                generate_task = asyncio.create_task(self.generate(payload))
                termination_event_watcher = asyncio.create_task(termination_event.wait())
                done, pending = await asyncio.wait(
                    [generate_task, termination_event_watcher],
                    timeout=60,
                    return_when=asyncio.FIRST_COMPLETED,
                )
                if generate_task in done:
                    output[idx] = generate_task.result()
                elif termination_event.is_set():
                    # cancel the pending task
                    if not generate_task.done():
                        generate_task.cancel()
                        try:
                            # complete cleanup for the cancelled task
                            await generate_task
                        except asyncio.CancelledError:
                            logger.error("Exception in cancelling task: ", exc_info=True)
                    queue.task_done()
                    marked_done = True
                    continue
                else:
                    logger.error("Worker timeout, requeuing...")
                    # requeue the timeout tasks in base priority
                    await queue.put((self.base_priority, item))
            except Exception as exc:
                is_eval_exception = isinstance(exc, LLMEvalException)
                if (retry_count := abs(priority)) <= self.max_retries and not is_eval_exception:
                    logger.error(f"Exception in worker on attempt {retry_count + 1}: raised {repr(exc)}")
                    await queue.put((priority - 1, item))
                else:
                    logger.error(f"Exception in worker: {traceback.format_exc()}")
                    if self.exit_on_error:
                        termination_event.set()
            finally:
                if not marked_done:
                    queue.task_done()
                if termination_event_watcher and not termination_event_watcher.done():
                    termination_event_watcher.cancel()

    async def execute(self, inputs: Sequence[Any]) -> List[Any]:
        termination_event = asyncio.Event()

        def termination_handler() -> None:
            termination_event.set()
            logger.info("Process was interrupted. The return value will be incomplete...")

        signal.signal(self.termination_signal, termination_handler)
        outputs = [self.fallback_return_value] * len(inputs)

        max_queue_size = 5 * self.concurrency
        max_fill = max_queue_size - (2 * self.concurrency)
        queue: asyncio.PriorityQueue[Tuple[int, Any]] = asyncio.PriorityQueue(maxsize=max_queue_size)
        done_producing = asyncio.Event()

        producer = asyncio.create_task(self.producer(inputs, queue, max_fill, done_producing, termination_event))
        consumers = [
            asyncio.create_task(self.consumer(outputs, queue, done_producing, termination_event))
            for _ in range(self.concurrency)
        ]

        await asyncio.gather(producer, *consumers)
        join_task = asyncio.create_task(queue.join())
        termination_event_watcher = asyncio.create_task(termination_event.wait())
        done, pending = await asyncio.wait([join_task, termination_event_watcher], return_when=asyncio.FIRST_COMPLETED)
        if termination_event_watcher in done:
            # Cancel all tasks
            if not join_task.done():
                join_task.cancel()
            if not producer.done():
                producer.cancel()
            for task in consumers:
                if not task.done():
                    task.cancel()

        if not termination_event_watcher.done():
            termination_event_watcher.cancel()

        # reset the SIGTERM handler
        signal.signal(self.termination_signal, signal.SIG_DFL)
        return outputs

    def run(self, inputs: Sequence[Any]) -> List[Any]:
        return asyncio.run(self.execute(inputs))


class SyncExecutor(Executor):
    """Synchronous executor with a generation function."""

    def __init__(
        self,
        generation_fn: Callable[[Any], Any],
        max_retries: int = 10,
        exit_on_error: bool = True,
        fallback_return_value: Union[Any, Any] = None,
        termination_signal: signal.Signals = signal.SIGINT,
    ):
        self.generate = generation_fn
        self.fallback_return_value = fallback_return_value
        self.max_retries = max_retries
        self.exit_on_error = exit_on_error
        self.termination_signal = termination_signal
        self._terminate = False

    def _signal_handler(self) -> None:
        logger.error("Process was interrupted. The return value will be incomplete...")
        self._terminate = True

    def run(self, inputs: Sequence[Any]) -> List[Any]:
        signal.signal(self.termination_signal, self._signal_handler)
        outputs = [self.fallback_return_value] * len(inputs)

        for idx, input in enumerate(inputs):
            for attempt in range(self.max_retries + 1):
                if self._terminate:
                    return outputs
                try:
                    result = self.generate(input)
                    outputs[idx] = result
                    break
                except Exception as exc:
                    is_eval_exception = isinstance(exc, LLMEvalException)
                    if attempt >= self.max_retries or is_eval_exception:
                        logger.error("Exception in worker: ", exc_info=True)
                        if self.exit_on_error:
                            return outputs
                    else:
                        logger.error(f"Exception in worker on attempt {attempt + 1}: ", exc_info=True)

        # reset the handler
        signal.signal(self.termination_signal, signal.SIG_DFL)
        return outputs


def get_executor_on_sync_context(
    sync_fn: Callable[[Any], Any],
    async_fn: Callable[[Any], Coroutine[Any, Any, Any]],
    run_sync: bool = False,
    concurrency: int = 3,
    exit_on_error: bool = True,
    fallback_return_value: Union[Any, Any] = None,
) -> Executor:
    if run_sync:
        return SyncExecutor(
            sync_fn,
            exit_on_error=exit_on_error,
            fallback_return_value=fallback_return_value,
        )

    if _running_event_loop_exists():
        if getattr(asyncio, "_nest_patched", False):
            return AsyncExecutor(
                async_fn,
                concurrency=concurrency,
                exit_on_error=exit_on_error,
                fallback_return_value=fallback_return_value,
            )
        else:
            logger.warning("The event loop with nest_asyncio will allow asynchronous eval submission significantly "
                           "faster. To patch the event loop, run `nest_asyncio.apply()`.")
            return SyncExecutor(
                sync_fn,
                exit_on_error=exit_on_error,
                fallback_return_value=fallback_return_value,
            )
    else:
        return AsyncExecutor(
            async_fn,
            concurrency=concurrency,
            exit_on_error=exit_on_error,
            fallback_return_value=fallback_return_value,
        )


def _running_event_loop_exists() -> bool:
    """Check if event loop exists."""
    try:
        asyncio.get_running_loop()
        return True
    except RuntimeError:
        return False


class RunEvalsPayload(NamedTuple):
    evaluator: LLMEvaluator
    record: Record


def run_evals(dataframe: DataFrame,
              evaluators: List[LLMEvaluator],
              provide_explanation: bool = False,
              use_function_calling_if_available: bool = True,
              verbose: bool = False,
              concurrency: Optional[int] = None,
              run_sync: bool = False) -> List[DataFrame]:
    """Run with a list of evaluators for evaluation."""
    if concurrency is None:
        if len(evaluators) == 0:
            concurrency = 1
        else:
            concurrency = min(evaluator.default_concurrency for evaluator in evaluators)

    # reload to make sure async evals work properly
    for evaluator in evaluators:
        evaluator.reload_client()

    async def _async_run_eval(payload: RunEvalsPayload,) -> Tuple[Label, Score, Explanation]:
        return await payload.evaluator.async_evaluate(
            payload.record,
            provide_explanation=provide_explanation,
            use_function_calling_if_available=use_function_calling_if_available,
            verbose=verbose,
        )

    def _run_eval(payload: RunEvalsPayload,) -> Tuple[Label, Score, Explanation]:
        return payload.evaluator.evaluate(
            payload.record,
            provide_explanation=provide_explanation,
            use_function_calling_if_available=use_function_calling_if_available,
            verbose=verbose,
        )

    executor = get_executor_on_sync_context(
        _run_eval,
        _async_run_eval,
        run_sync=run_sync,
        concurrency=concurrency,
        exit_on_error=True,
        fallback_return_value=(None, None, None),
    )

    total_records = len(dataframe)
    payloads = [
        RunEvalsPayload(evaluator=evaluator, record=row)
        for evaluator, (_, row) in product(evaluators, dataframe.iterrows())
    ]
    eval_results: List[DefaultDict[Index,
                                   Dict[ColumnName,
                                        Union[Label,
                                              Explanation]]]] = [defaultdict(dict) for _ in range(len(evaluators))]
    for idx, (label, score, explanation) in enumerate(executor.run(payloads)):
        evaluator_idx = idx // total_records
        row_idx = idx % total_records
        eval_results[evaluator_idx][row_idx]["label"] = label
        eval_results[evaluator_idx][row_idx]["score"] = score
        if provide_explanation:
            eval_results[evaluator_idx][row_idx]["explanation"] = explanation
        for col in constants.OUTPUT_EVAL_COLS:
            if col in dataframe.columns:
                eval_results[evaluator_idx][row_idx][col] = dataframe[col][row_idx]
    eval_dataframes: List[DataFrame] = []

    for idx, eval_result in enumerate(eval_results):
        eval_data = [eval_result[row_idx] for row_idx in range(len(eval_result))]
        eval_data = DataFrame(eval_data, index=dataframe.index)
        if constants.IDX in eval_data.columns:
            cols = list(eval_data.columns.drop(constants.IDX))
            eval_data = eval_data.groupby([constants.IDX]).agg({c: list for c in cols}).reset_index()
            # replace trace_id and span_id with the same id
            # e.g.
            # [['label', 'score', 'trace_id', 'span_id', 'document_id', 'document_score'],
            #  [[[相关], [相关]], [[1], [1]], 'e907777b18c32fbea48ed2cce4741628', '954d92cc74920c6b',
            #  ['336ee4d2-ba27-4e0c-8181-5596cde3d951', '850c24c6-f7ac-494c-858d-b27f0b710d99'],
            #  [0.5730395145260837, 0.5550109315577139]]
            if constants.TRACE_ID in eval_data.columns:
                eval_data[constants.TRACE_ID] = eval_data[constants.TRACE_ID].apply(lambda x: x[0])
                eval_data.drop(constants.IDX, axis=1, inplace=True)
            if constants.SPAN_ID in eval_data.columns:
                eval_data[constants.SPAN_ID] = eval_data[constants.SPAN_ID].apply(lambda x: x[0])

        eval_data[constants.METRIC_NAME] = evaluators[idx].metric_name
        if constants.DOC_ID in eval_data.columns or constants.DOC_SCORE in eval_data.columns:
            eval_data[constants.EVAL_TYPE] = constants.SpanType.RETRIEVE
        else:
            eval_data[constants.EVAL_TYPE] = constants.SpanType.LLM
        eval_dataframes.append(eval_data)

    return eval_dataframes

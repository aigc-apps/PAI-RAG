class LLMEvalException(Exception):
    pass


class LLMEvalContextLimitExceeded(LLMEvalException):
    pass


class RagEvalDataSetException(LLMEvalException):
    pass


class RagEvalDataValidationException(LLMEvalException):
    pass


class EvalPipelineCalMetricsException(LLMEvalException):
    pass

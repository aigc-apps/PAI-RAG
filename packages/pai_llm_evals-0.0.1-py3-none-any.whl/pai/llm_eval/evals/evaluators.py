import logging
from textwrap import indent
from typing import List, Mapping, Optional, Tuple, Type

from ..common import eval_constants as constants
from ..common.eval_utils import (
    openai_function_call_kwargs,
    parse_openai_function_call,
    log_args,
    snap_to_rail,
)
from .default_templates import EvalCriteria
from .models.base_model import BaseModel, set_verbosity
from .templates import ClassificationTemplate, PromptOptions


class LLMEvaluator:
    """Use LLM to evaluate records."""
    # pylint: disable=C0103
    Record = Mapping[str, str]

    def __init__(
        self,
        model: BaseModel,
        template: ClassificationTemplate,
    ) -> None:
        self._model = model
        self._template = template
        self.metric_name = template.metric_name

    @property
    def default_concurrency(self) -> int:
        return constants.DEFAULT_CONCURRENCY

    def reload_client(self) -> None:
        self._model.reload_client()

    def evaluate(
        self,
        record: Record,
        provide_explanation: bool = False,
        use_function_calling_if_available: bool = True,
        verbose: bool = False,
    ) -> Tuple[str, Optional[float], Optional[str]]:
        """Evaluate a record."""
        use_openai_function_call = use_function_calling_if_available
        prompt = self._template.format(record, options=PromptOptions(provide_explanation=provide_explanation))
        with set_verbosity(self._model, verbose) as verbose_model:
            unparsed_output = verbose_model(
                prompt,
                **(openai_function_call_kwargs(self._template.rails, provide_explanation)
                   if use_openai_function_call else {}),
            )
        label, explanation = _extract_label_and_explanation(
            unparsed_output=unparsed_output,
            template=self._template,
            provide_explanation=provide_explanation,
            use_openai_function_call=use_openai_function_call,
            verbose=verbose,
        )
        score = self._template.score(label) if label != constants.INVALID else None
        return label, score, explanation

    async def async_evaluate(
        self,
        record: Record,
        provide_explanation: bool = False,
        use_function_calling_if_available: bool = True,
        verbose: bool = False,
    ) -> Tuple[str, Optional[float], Optional[str]]:
        """Evaluate a record."""
        use_openai_function_call = use_function_calling_if_available
        prompt = self._template.format(record, options=PromptOptions(provide_explanation=provide_explanation))
        with set_verbosity(self._model, verbose) as verbose_model:
            unparsed_output = await verbose_model._async_generate(
                prompt,
                **(openai_function_call_kwargs(self._template.rails, provide_explanation)
                   if use_openai_function_call else {}),
            )
        label, explanation = _extract_label_and_explanation(
            unparsed_output=unparsed_output,
            template=self._template,
            provide_explanation=provide_explanation,
            use_openai_function_call=use_openai_function_call,
            verbose=verbose,
        )
        score = self._template.score(label)
        return label, score, explanation

    @staticmethod
    def create_llm_evaluator_subclass(class_name: str, template: ClassificationTemplate,
                                      docstring: str) -> Type['LLMEvaluator']:
        """Create subclasses of LLMEvaluator."""

        # pylint: disable=C0103
        def __init__(self: LLMEvaluator, model: BaseModel) -> None:
            LLMEvaluator.__init__(self, model, template)

        __init__.__doc__ = f"""
            Initializer for {class_name}.

            Args:
                model (BaseEvalModel): The LLM model to use for evaluation."""

        docstring += f" Outputs railed classes {', '.join(template.rails)}."
        docstring += "\n\nThe template used for evaluation (without explanation) is:\n\n"
        docstring += indent(template.template, 2 * constants.TAB)

        return type(class_name, (LLMEvaluator,), {"__init__": __init__, "__doc__": docstring})


(
    FaithfulnessEvaluator,
    RetrieverRelevanceEvaluator,
    RAGCorrectnessEvaluator,
) = map(
    lambda args: LLMEvaluator.create_llm_evaluator_subclass(*args),
    (
        (
            constants.FAITHFULNESS_EVALUATOR,
            EvalCriteria.FAITHFULNESS.value,
            constants.FAITHFULNESS_EVALUATOR_DOC_STR,
        ),
        (
            constants.RETRIEVER_RELEVANCE_EVALUATOR,
            EvalCriteria.RETRIEVER_RELEVANCE.value,
            constants.RETRIEVER_RELEVANCE_EVALUATOR_DOC_STR,
        ),
        (
            constants.RAG_CORRECTNESS_EVALUATOR,
            EvalCriteria.RAG_CORRECTNESS.value,
            constants.RAG_CORRECTNESS_EVALUATOR_DOC_STR,
        ),
    ),
)


def _extract_label_and_explanation(
    unparsed_output: str,
    template: ClassificationTemplate,
    provide_explanation: bool,
    use_openai_function_call: bool,
    verbose: bool,
) -> Tuple[List[str], Optional[str]]:
    """Extract the label and explanation from the invalid output."""
    if not use_openai_function_call:
        if provide_explanation:
            label, explanation = (
                template.extract_label_from_explanation(unparsed_output),
                unparsed_output,
            )
            if label == constants.INVALID:
                log_args(
                    verbose,
                    logging.WARNING,
                    f", failed to parse {repr(unparsed_output)}",
                )
                unrailed_label = [unparsed_output]
            else:
                unrailed_label = [label]
        else:
            explanation = None
            unrailed_label = [unparsed_output]
    else:
        unrailed_label, explanation = parse_openai_function_call(unparsed_output)
    return snap_to_rail(unrailed_label, template.rails, verbose=verbose), explanation

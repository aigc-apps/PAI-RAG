from dataclasses import dataclass, field
from typing import Iterable, Optional, cast

import numpy as np
import pandas as pd
from sklearn.metrics import ndcg_score


#pylint: disable=invalid-name
@dataclass(frozen=True)
class RetrievalMetrics:
    """Retrieval metrics are used to evaluate the retrieval system with ranking scores in descending order.

    For more information about these metrics:
    https://cran.r-project.org/web/packages/recometrics/vignettes/Evaluating_recommender_systems.html
    """

    eval_scores: "pd.Series[float]"
    length: int = field(init=False)
    has_nan: bool = field(init=False)

    def __init__(self, eval_scores: Iterable[float]) -> None:
        _eval_scores = np.fromiter(eval_scores, dtype=float)
        object.__setattr__(self, "length", len(_eval_scores))
        object.__setattr__(self, "has_nan", not np.all(np.isfinite(_eval_scores)))
        if self.length < 2:
            # pad with zeros when length less than 2 for sklearn.metrics.ndcg_score
            _scores = _eval_scores
            _eval_scores = np.zeros(2)
            _eval_scores[:len(_scores)] = _scores
        # For ranking metrics, assign ranking scores with the indices
        # in descending order.
        ranking_scores = reversed(range(len(_eval_scores)))
        object.__setattr__(
            self,
            "eval_scores",
            pd.Series(_eval_scores, dtype=float, index=ranking_scores),
        )

    def ndcg(self, k: Optional[int] = None) -> float:
        """Normalized Discounted Cumulative Gain (NDCG) at `k` with log base 2 discounting."""
        if self.has_nan:
            return None
        if k is None:
            k = self.length
        if k < 1:
            return 0.0
        y_true = [self.eval_scores]
        y_score = [self.eval_scores.index]

        return cast(float, ndcg_score(y_true=y_true, y_score=y_score, k=k, ignore_ties=True))

    def precision(self, k: Optional[int] = None) -> float:
        """Calculate the fraction of true scores among first `k` positions (1-based index)."""
        if self.has_nan:
            return None
        if k is None:
            k = self.length
        if k < 1:
            return 0.0
        return self.eval_scores[:k].astype(bool).sum() / k

    def reciprocal_rank(self) -> float:
        """Calculate the reciprocal rank of the first hit."""
        for i, score in enumerate(self.eval_scores):
            if not np.isfinite(score):
                return None
            if score:
                return 1 / (i + 1)
        return 0.0

    def hit(self) -> float:
        """Check if any true score exists.

        Hit rate can be calculated by the average of the hit metric across users
        """
        if self.eval_scores.any():
            return 1.0
        if self.has_nan:
            return None
        return 0.0

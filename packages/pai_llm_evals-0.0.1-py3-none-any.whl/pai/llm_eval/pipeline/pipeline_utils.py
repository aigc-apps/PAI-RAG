import logging
import math
from .eval_pipeline import EvalClient, EvalPipeline, TraceConfig
from ..common import eval_constants as constants


def run_trace_offline_eval_pipeline(eval_prompt_templates: str,
                                    eval_name: str = 'trace_offline_eval',
                                    min_time: str = None,
                                    max_time: str = None,
                                    config_path: str = None,
                                    region: str = None,
                                    endpoint: str = None,
                                    eval_app_type: str = constants.EvalAppType.RAG,
                                    batch_size: int = 1,
                                    need_data_management: bool = False,
                                    **model_config) -> None:
    """Run offline eval pipeline for trace data.

    Args:

        :param eval_prompt_templates: select the prompt template[s] for eval.
        :param eval_name: provide eval name for eval service API. Default: trace_data_eval.
        :param max_time: specify the max time for trace service API.
        :param min_time: specify the min time for trace service API.
        :param config_path: provide the config path to access trace/eval service API. If not provided, it will
                            automatically create the config with endpoint and region. Default: None.
        :param region: specify the region for trace/eval service API. Default: None.
        :param endpoint: specify the endpoint for trace/eval service API. Default: None.
        :param eval_app_type: specify the eval app type for eval pipeline to calculate metrics. Default: rag.
        :param batch_size: specify the eval data number for each request to eval service. Default: 1.
        :param need_data_management: specify if need data management by eval service. Default: False.
        :param model_config: config model config for LLM service.
    Returns: List[str]
    """
    return _run_offline_eval_pipeline(eval_prompt_templates,
                                      eval_name=eval_name,
                                      min_time=min_time,
                                      max_time=max_time,
                                      config_path=config_path,
                                      region=region,
                                      endpoint=endpoint,
                                      eval_app_type=eval_app_type,
                                      batch_size=batch_size,
                                      data_source=constants.EvalDataSource.TRACE,
                                      need_data_management=need_data_management,
                                      **model_config)


def run_rag_offline_eval_pipeline(eval_prompt_templates,
                                  eval_data_path,
                                  eval_name='rag_offline_eval',
                                  config_path=None,
                                  region=None,
                                  endpoint=None,
                                  batch_size=1,
                                  need_data_management=False,
                                  **model_config):
    """Run offline eval pipeline for rag dataset.

    Args:

        :param eval_prompt_templates: select the prompt template[s] for eval.
        :param eval_data_path: provide offline data file path for eval
        :param eval_name: provide eval name for eval service API. Default: trace_data_eval.
        :param config_path: provide the config path to access trace/eval service API. If not provided, it will
                            automatically create the config with endpoint and region. Default: None.
        :param region: specify the region for trace/eval service API. Default: None.
        :param endpoint: specify the endpoint for trace/eval service API. Default: None.
        :param batch_size: specify the eval data number for each request to eval service. Default: 1.
        :param need_data_management: specify if need data management by eval service. Default: False.
        :param model_config: config model config for LLM service.
    Returns: List[str]
    """
    return _run_offline_eval_pipeline(eval_prompt_templates,
                                      eval_name=eval_name,
                                      eval_data_path=eval_data_path,
                                      config_path=config_path,
                                      region=region,
                                      endpoint=endpoint,
                                      eval_app_type=constants.EvalAppType.RAG,
                                      batch_size=batch_size,
                                      data_source=constants.EvalDataSource.RAG,
                                      need_data_management=need_data_management,
                                      **model_config)


def _run_offline_eval_pipeline(eval_prompt_templates: str,
                               eval_name: str,
                               eval_data_path: str = None,
                               min_time: str = None,
                               max_time: str = None,
                               config_path: str = None,
                               region: str = None,
                               endpoint: str = None,
                               eval_app_type: str = constants.EvalAppType.RAG,
                               batch_size: int = 1,
                               data_source: str = constants.EvalDataSource.TRACE,
                               need_data_management: bool = False,
                               **model_config) -> None:
    """Run offline eval pipeline.

    Args:

        :param eval_prompt_templates: select the prompt template[s] for eval.
        :param eval_name: provide eval name for eval service API.
        :param eval_data_path: provide offline data file path for eval
        :param max_time: specify the max time for trace service API.
        :param min_time: specify the min time for trace service API.
        :param config_path: provide the config path to access trace/eval service API. If not provided, it will
                            automatically create the config with endpoint and region. Default: None.
        :param region: specify the region for trace/eval service API. Default: None.
        :param endpoint: specify the endpoint for trace/eval service API. Default: None.
        :param eval_app_type: specify the eval app type for eval pipeline to calculate metrics. Default: rag.
        :param batch_size: specify the eval data number for each request to eval service. Default: 1.
        :param data_source: specify the eval data source. Default: trace
        :param need_data_management: specify if need data management by eval service. Default: False.
        :param model_config: config model config for LLM service.
    Returns: List[str]
    """
    if not config_path and (need_data_management or data_source == constants.EvalDataSource.TRACE):
        if not region:
            raise ValueError(f'Invalid trace API region')
        if not endpoint:
            raise ValueError('Invalid trace API endpoint')
        config = TraceConfig.create_config(region, endpoint)
        config_path = TraceConfig.save_config(config)
    if need_data_management:
        eval_client = EvalClient(config_path=config_path)
        # create eval in db
        resp = eval_client.create_eval(None, eval_name)
        eval_id = resp.body.evaluation_id
        logging.info('Created eval')
    if data_source == constants.EvalDataSource.TRACE:
        retrieval_df, response_df = EvalPipeline.prepare_data(min_time=min_time,
                                                              max_time=max_time,
                                                              config_path=config_path)
        index = [constants.TRACE_ID, constants.METRIC_NAME]
    else:
        retrieval_df, response_df = EvalPipeline.prepare_data(file_path=eval_data_path, data_source=data_source)
        index = [constants.IDX, constants.METRIC_NAME]

    num_batch = math.ceil(len(response_df) / batch_size)
    retrieve_eval_cols = [constants.DOC_ID, constants.DOC_SCORE]
    eval_res = []
    for batch_idx in range(num_batch):
        eval_df = EvalPipeline.eval_metrics(eval_app_type, retrieval_df, response_df, eval_prompt_templates, index,
                                            retrieve_eval_cols, batch_idx, batch_size, data_source, **model_config)
        if eval_df is None:
            continue
        eval_res.append(eval_df.to_json())
        if not need_data_management:
            continue
        # Todo: will rename or save separate fields for the index column
        if data_source == constants.EvalDataSource.RAG:
            eval_df.rename(columns={constants.IDX: constants.TRACE_ID}, inplace=True)
        # save eval results in db
        eval_client.append_eval_result(eval_id, eval_df.to_json())
        logging.info('Append eval result')
    return eval_res

import configparser
import json
import logging
import os
import uuid
import multiprocessing
import pandas as pd

from alibabacloud_paillmtrace20240311 import models
from alibabacloud_paillmtrace20240311.client import Client
from alibabacloud_tea_openapi import models as open_api_models

from ..evals.models.themis_model import ThemisModel
from ..evals.models.qwen_model import QWenModel
from ..evals.models.openai_model import OpenAIModel
from ..evals.evaluators import LLMEvaluator
from ..evals.executors import run_evals
from ..evals.exceptions import EvalPipelineCalMetricsException
from ..common import eval_constants as constants
from ..common import eval_utils
from ..data.trace_data_adapter import TraceDataAdapter
from ..data.rag_data_adapter import RagOfflineEvalDataAdapter
from ..data.data_reader import TraceDataReader
from ..data.data_utils import validate_eval_data
from ..data.dataset import RagEvalDataSet

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TraceConfig:

    @staticmethod
    def create_config(region, endpoint):
        # create config
        if not (access_key_id := os.getenv("ACCESS_KEY_ID")):
            raise ValueError('Missing access key id for llm trace service')
        os.environ["ACCESS_KEY_ID"] = access_key_id
        if not (access_key_secret := os.getenv("ACCESS_KEY_SECRET")):
            raise ValueError('Missing access key secret for llm trace service')
        os.environ["ACCESS_KEY_SECRET"] = access_key_secret
        # config
        config = configparser.ConfigParser()
        config['trace'] = {
            'access_key_id': access_key_id,
            'access_key_secret': access_key_secret,
            'region': region,
            'endpoint': endpoint
        }
        return config

    @staticmethod
    def save_config(config, path='~/.llm_trace_data_reader.ini'):
        # save config
        config_path = os.path.expanduser(path)
        with open(config_path, 'w+') as cfg:
            config.write(cfg)
        return config_path


class EvalPipeline:

    @staticmethod
    def prepare_data(min_time=None,
                     max_time=None,
                     config_path=None,
                     file_path=None,
                     data_source=constants.EvalDataSource.TRACE):
        if data_source == constants.EvalDataSource.TRACE:
            res = TraceDataReader(config_path)
            eval_input_data = res.read_data(min_time=min_time, max_time=max_time)
            da = TraceDataAdapter()
        elif data_source == constants.EvalDataSource.RAG:
            eval_input_data = RagEvalDataSet(file_path).get_df()
            da = RagOfflineEvalDataAdapter()
        else:
            err_msg = f'Invalid data source: {data_source}'
            logger.error(err_msg)
            raise ValueError(err_msg)
        da.convert(eval_input_data)
        retrieval_df = da.get_retrieve_data()
        response_df = da.get_response_data()
        return retrieval_df, response_df

    @staticmethod
    def select_llm(model_name=None,
                   model_api_key=None,
                   model_base_url=None,
                   temperature=0.85,
                   top_p=0.99,
                   is_self_host=False,
                   use_function_call=False):
        """Support Themis | Qwen | GPT models."""
        if model_name:
            model_name = model_name.lower()
        if not is_self_host and model_name and constants.ModelPrefix.THEMIS in model_name:
            if use_function_call:
                raise ValueError('Not supporting function call for Themis model')
            if not model_api_key and not (model_api_key := os.getenv(constants.THEMIS_API_KEY)):
                raise ValueError('Missing Themis model api key')
            os.environ[constants.THEMIS_API_KEY] = model_api_key
            if model_base_url:
                eval_model = ThemisModel(model=model_name, base_url=model_base_url)
            else:
                eval_model = ThemisModel(model=model_name)
        elif not is_self_host and model_name and constants.ModelPrefix.QWEN in model_name:
            if not model_api_key and not (model_api_key := os.getenv(constants.DASHSCOPE_API_KEY)):
                raise ValueError('Missing DASHSCOPE api key')
            os.environ[constants.DASHSCOPE_API_KEY] = model_api_key
            if model_base_url:
                eval_model = QWenModel(model=model_name, base_url=model_base_url, top_p=top_p)
            else:
                eval_model = QWenModel(model=model_name, top_p=top_p)
        elif not is_self_host and model_name and constants.ModelPrefix.GPT in model_name:
            if not model_api_key and not (model_api_key := os.getenv(constants.OPENAI_API_KEY)):
                raise ValueError('Missing OPENAI api key')
            os.environ[constants.OPENAI_API_KEY] = model_api_key
            if model_base_url:
                eval_model = OpenAIModel(model=model_name, base_url=model_base_url)
            else:
                eval_model = OpenAIModel(model=model_name)
        else:
            # Support the OPENAI-compatible self-hosted LLM service
            if use_function_call:
                raise ValueError('Not supporting function call for self-hosted model')
            err_msg = ''
            if not model_api_key and not (model_api_key := os.getenv(constants.MODEL_API_KEY)):
                err_msg += 'Missing model api key. '
            if not model_base_url and not (model_base_url := os.getenv(constants.MODEL_BASE_URL)):
                err_msg += 'Missing model base url.'
            if err_msg:
                raise ValueError(f'Error: {err_msg}')
            if not model_name:
                logger.warning(f'Missing model name. Use `default`')
                model_name = 'default'
            eval_model = OpenAIModel(model=model_name,
                                     api_key=model_api_key,
                                     base_url=model_base_url,
                                     temperature=temperature)
        return eval_model

    @staticmethod
    def calculate_eval_metrics(eval_app_type,
                               retrieval_df,
                               response_df,
                               eval_prompt_template,
                               retrieve_eval_cols,
                               batch_idx,
                               batch_size,
                               index,
                               model_config,
                               data_source='trace'):
        eval_model = EvalPipeline.select_llm(**model_config)
        use_function_calling = model_config.get(constants.USE_FUNCTION_CALL, False)
        cur_index = index
        run_llm_eval = True
        calc_retrieve_metrics = False
        evaluator = LLMEvaluator(eval_model, eval_prompt_template)
        if evaluator.metric_name == constants.RETRIEVER_RELEVANCE:
            if constants.REFERENCE_ID in retrieval_df:
                retrieval_df[constants.REFERENCE_ID] = retrieval_df[constants.REFERENCE_ID].apply(str)
                run_llm_eval = False
            idx_name = 'trace_id' if data_source == constants.EvalDataSource.TRACE else 'idx'
            df = retrieval_df[retrieval_df[idx_name].isin(response_df[idx_name][batch_idx:batch_idx + batch_size])]
            calc_retrieve_metrics = True
        else:
            df = response_df[batch_idx:batch_idx + batch_size]
        df = df.reset_index(drop=True)
        if run_llm_eval:
            cur_eval_df = run_evals(
                dataframe=df,
                evaluators=[evaluator],
                provide_explanation=True,
                use_function_calling_if_available=use_function_calling,
                verbose=True,
            )[0]
            drop_cols = constants.TRACE_DROP_COLS \
                if data_source == constants.EvalDataSource.TRACE else constants.DROP_COLS
            cur_eval_df = cur_eval_df.drop(drop_cols, axis=1)

            if eval_app_type == constants.EvalAppType.RAG and pd.Index(retrieve_eval_cols).isin(
                    cur_eval_df.columns).all():
                cur_index = index + retrieve_eval_cols

        else:
            df[constants.METRIC_NAME] = constants.RETRIEVER_RELEVANCE
            cur_index = index + retrieve_eval_cols
            cur_eval_df = (df[cur_index].groupby(index + [constants.REFERENCE_ID]).agg({
                'document_id':
                lambda x: ','.join(x).split(','),
                'document_score':
                lambda x: ','.join(map(str, x)).split(',')
            }).reset_index())
            cur_eval_df[constants.REFERENCE_ID] = cur_eval_df[constants.REFERENCE_ID].apply(eval_utils.to_list)
            cur_eval_df['score'] = cur_eval_df.apply(
                lambda x: [1 if c in x[constants.REFERENCE_ID] else 0 for c in x[constants.DOC_ID]], axis=1)
        return cur_eval_df, cur_index, calc_retrieve_metrics

    @staticmethod
    def eval_metrics(eval_app_type,
                     retrieval_df,
                     response_df,
                     eval_prompt_templates,
                     index,
                     retrieve_eval_cols=[constants.DOC_ID, constants.DOC_SCORE],
                     batch_idx=0,
                     batch_size=1,
                     data_source='trace',
                     **model_config):
        # Create LLM evaluators with eval model and prompt templates
        eval_df = None
        # multi-processing
        pool = multiprocessing.Pool(processes=constants.PROCESS_NUM)
        try:
            eval_results = []
            merge_index_name = 'trace_id' if data_source == 'trace' else 'idx'
            if constants.REFERENCE_ID in retrieval_df and constants.REFERENCE_ID not in retrieve_eval_cols:
                retrieve_eval_cols += [constants.REFERENCE_ID]
            for eval_prompt_template in eval_prompt_templates:
                eval_result = pool.apply_async(func=EvalPipeline.calculate_eval_metrics,
                                               args=(eval_app_type, retrieval_df, response_df, eval_prompt_template,
                                                     retrieve_eval_cols, batch_idx, batch_size, index, model_config,
                                                     data_source))
                eval_results.append(eval_result)
            # close the pool and wait for all tasks to complete
            pool.close()
            pool.join()
            for eval_result in eval_results:
                try:
                    cur_eval_df, cur_index, calc_retrieve_metrics = eval_result.get()
                except EvalPipelineCalMetricsException:
                    logger.exception("Error retrieving eval_result", exc_info=True)
                cur_eval_df = cur_eval_df[cur_index].assign(eval_results=cur_eval_df.drop(cur_index, axis=1).to_dict(
                    orient='records'))
                if calc_retrieve_metrics:
                    cur_eval_df[constants.EVAL_RESULTS].apply(
                        lambda x: x.update(eval_utils.calculate_retrieve_metrics(x['score'])))

                if eval_df is not None:
                    cur_eval_df = cur_eval_df.rename(columns={constants.EVAL_RESULTS: 'cur_eval_results'})
                    eval_df[constants.EVAL_RESULTS] = (pd.merge(eval_df, cur_eval_df,
                                                                on=merge_index_name).apply(lambda x: {
                                                                    **x[constants.EVAL_RESULTS],
                                                                    **{
                                                                        x['metric_name']: x['cur_eval_results']
                                                                    }
                                                                },
                                                                                           axis=1))
                else:
                    cur_eval_df[constants.EVAL_RESULTS] = cur_eval_df.apply(
                        lambda x: {x['metric_name']: x[constants.EVAL_RESULTS]}, axis=1)
                    cur_eval_df = cur_eval_df.drop(['metric_name'], axis=1)
                    eval_df = cur_eval_df
        except EvalPipelineCalMetricsException:
            logger.exception(f"Error in calculate eval metrics process", exc_info=True)

        if eval_df is None:
            logger.warning(f'Empty eval df, batch id: {batch_idx}')
            return eval_df
        if eval_app_type == constants.EvalAppType.RAG and pd.Index(retrieve_eval_cols).isin(eval_df.columns).all():
            eval_df[constants.EVAL_RESULTS] = eval_df.apply(lambda x: {
                **x[constants.EVAL_RESULTS],
                **{
                    c: x[c]
                    for c in retrieve_eval_cols
                }
            },
                                                            axis=1)
            eval_df = eval_df.drop(retrieve_eval_cols, axis=1)
        eval_df[constants.EVAL_RESULTS] = eval_df.apply(lambda x: {eval_app_type: x[constants.EVAL_RESULTS]}, axis=1)
        return eval_df

    @staticmethod
    def eval(eval_prompt_templates, trace_data, eval_app_type=constants.EvalAppType.RAG, eval_id=None, **model_config):
        tda = TraceDataAdapter()
        tda.convert_trace_data(trace_data)
        retrieval_df = tda.get_retrieve_data()
        response_df = tda.get_response_data()
        err_msg = validate_eval_data(retrieval_df, response_df)
        if err_msg:
            logger.error(err_msg)
            raise ValueError(err_msg)
        index = [constants.TRACE_ID, constants.METRIC_NAME]
        retrieve_eval_cols = [constants.DOC_ID, constants.DOC_SCORE]
        batch_size = len(response_df)
        eval_df = EvalPipeline.eval_metrics(eval_app_type, retrieval_df, response_df, eval_prompt_templates, index,
                                            retrieve_eval_cols, 0, batch_size, **model_config)

        if not eval_id:
            eval_id = uuid.uuid1().hex
            logger.info(f'eval_id not exist! Create eval_id:{eval_id}')
        eval_df[constants.EVAL_ID] = eval_id
        return eval_df

    @staticmethod
    def parse_eval_results(eval_df: pd.DataFrame, include_doc_eval: bool = False) -> dict:
        err_msg = eval_utils.validate_eval_results(eval_df)
        if err_msg:
            raise ValueError(f'Invalid eval results: {err_msg}')
        eval_results = {}
        if len(eval_df) == 1:
            try:
                eval_results[constants.TRACE_ID] = eval_df.iloc[0][constants.TRACE_ID]
                eval_results[constants.EVAL_ID] = eval_df.iloc[0][constants.EVAL_ID]
                eval_results_dict = eval_df.iloc[0][constants.EVAL_RESULTS]
                if isinstance(eval_results_dict, str):
                    eval_results_dict = json.loads(eval_results_dict)
                eval_results.update(eval_utils.flat_eval_result(eval_results_dict, include_doc_eval))
            except Exception as e:
                err_msg = 'Failed to parse eval results'
                logger.error(err_msg, exc_info=True)
                raise ValueError(f'{err_msg}{e}')
        else:
            raise ValueError('Currently only support parsing the single trace eval result')
        return eval_results


class EvalClient:
    """Eval client for pop SDK."""

    def __init__(self, config_path=None):
        config = EvalClient._read_user_config(config_path)
        self._client = EvalClient._create_client(config['trace']['access_key_id'], config['trace']['access_key_secret'],
                                                 config['trace']['region'], config['trace']['endpoint'])

    @staticmethod
    def _create_client(access_key_id, access_key_secret, region, endpoint):
        config = open_api_models.Config(access_key_id=access_key_id,
                                        access_key_secret=access_key_secret,
                                        protocol='HTTPS',
                                        region_id=region,
                                        endpoint=endpoint)
        return Client(config)

    def create_eval(self, eval_data, eval_name):
        req = models.CreateEvalRequest(evaluation_data=eval_data, evaluation_name=eval_name)
        resp = self._client.create_eval(req)
        return resp

    def append_eval_result(self, eval_id, eval_data):
        req = models.AppendEvalResultRequest(evaluation_id=eval_id, evaluation_data=eval_data)
        resp = self._client.append_eval_result(req)
        return resp

    @staticmethod
    def _read_user_config(config_path):
        config = configparser.ConfigParser()
        if not config_path:
            config_path = os.getenv(constants.CONFIG_PATH)
        with open(config_path, 'r') as cfg:
            config.read_file(cfg)
        return config

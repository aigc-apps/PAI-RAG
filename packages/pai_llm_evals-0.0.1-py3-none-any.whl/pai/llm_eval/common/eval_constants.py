OPENAI_API_KEY = 'OPENAI_API_KEY'
OPENAI_MINIMUM_VERSION = '1.0.0'
OPENAI_LEGACY_COMPLETION_API_MODELS = ('gpt-3.5-turbo-instruct',)

INVALID = 'INVALID'
DEFAULT_START_DELIM = '{{'
DEFAULT_END_DELIM = '}}'

RESPONSE = 'response'
EXPLANATION = 'explanation'
FUNCTION_NAME = 'record_response'
TOOLS = 'tools'
TOOL_CHOICE = "tool_choice"
FUNCTION = 'function'

DEFAULT_CONCURRENCY = 5

# llm evaluator
FAITHFULNESS_EVALUATOR = 'FaithfulnessEvaluator'
RETRIEVER_RELEVANCE_EVALUATOR = 'RetrieverRelevanceEvaluator'
RAG_CORRECTNESS_EVALUATOR = 'RAGCorrectnessEvaluator'

FAITHFULNESS_EVALUATOR_DOC_STR = """
Leverages an LLM to evaluate whether a response (stored under an "output" column) is a hallucination 
given a query (stored under an "input" column) and one or more retrieved documents (stored under a "reference" column).
"""

RETRIEVER_RELEVANCE_EVALUATOR_DOC_STR = """
Leverages an LLM to evaluate whether a retrieved document (stored under a "reference" column) is relevant 
or irrelevant to the corresponding query (stored under the "input" column).
"""

RAG_CORRECTNESS_EVALUATOR_DOC_STR = """
Leverages an LLM to evaluate whether a response (stored under an "output" column) is correct or incorrect 
given a query (stored under an "input" column) and one or more retrieved documents (stored under a "reference" column).
"""

TAB = ' ' * 4

TRACE_ID = 'trace_id'
SPAN_ID = 'span_id'

INPUT = 'input'
OUTPUT = 'output'
REFERENCE = 'reference'
DOC_POS = 'document_position'
DOC_SCORE = 'document_score'
DOC_ID = 'document_id'
REFERENCE_ID = 'reference_id'

INPUT_VALUE = 'input.value'
OUTPUT_VALUE = 'output.value'
KEY = 'key'
VALUE = 'value'
STRING_VALUE = 'string_value'

PROMPT_TEMPLATE_VARS = 'gen_ai.prompt_template.variables'
QUERY_STR = 'query_str'
CONTEXT_STR = 'context_str'

RETRIEVAL_DOCUMENTS = 'retrieval.documents'
DOCUMENT_SCORE = 'document.score'
DOCUMENT_CONTENT = 'document.content'
DOCUMENT_ID = 'document.id'
VECTOR_INDEX = 'vector_index'

IDX = 'idx'


class SpanType:
    LLM = 'llm'
    RETRIEVE = 'retrieve'


CONFIG_PATH = 'config_path'

# LLM API

DASHSCOPE_API_KEY = 'DASHSCOPE_API_KEY'
DASHSCOPE_BASE_URL = 'https://dashscope.aliyuncs.com/compatible-mode/v1'

THEMIS_API_KEY = 'THEMIS_API_KEY'
THEMIS_BASE_URL = 'http://ai-service.ce8cc13b6421545749e7b4605f3d02607.cn-hangzhou.alicontainer.com/v1'

OUTPUT_EVAL_COLS = [TRACE_ID, SPAN_ID, DOC_ID, DOC_SCORE, IDX]

EVAL_TYPE = 'eval_type'
EVAL_ID = 'eval_id'
# metrics
METRIC_NAME = 'metric_name'
RAG_CORRECTNESS = 'rag_correctness'
FAITHFULNESS = 'faithfulness'
RETRIEVER_RELEVANCE = 'retriever_relevance'

HIT_RATE = 'hit_rate'
MRR = 'mrr'
NDCG = 'ndcg'
PRECISION = 'precision'
RETRIEVE_METRICS = [HIT_RATE, MRR, NDCG, PRECISION]
# remove columns after evaluation
DROP_COLS = [EXPLANATION, EVAL_TYPE]
# remove columns after trace data evaluation
TRACE_DROP_COLS = DROP_COLS + [SPAN_ID]
EVAL_RESULTS = 'eval_results'
LABEL = 'label'
SCORE = 'score'

PROCESS_NUM = 3

MODEL_BASE_URL = 'MODEL_BASE_URL'
MODEL_API_KEY = 'MODEL_API_KEY'

USE_FUNCTION_CALL = 'use_function_call'


class EvalAppType:
    RAG = 'rag'
    # add other eval app types


class EvalDataSource:
    TRACE = 'trace'
    RAG = 'rag'


class ModelPrefix:
    THEMIS = 'themis'
    QWEN = 'qwen'
    GPT = 'gpt'

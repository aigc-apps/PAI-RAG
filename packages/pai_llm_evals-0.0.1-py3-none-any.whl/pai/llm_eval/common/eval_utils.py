import json
import logging
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from pai.llm_eval.metrics.retrieval_metrics import RetrievalMetrics
from . import eval_constants

logger = logging.getLogger(__name__)


def snap_to_rail(raw_strings: List[str], rails: List[str], verbose: bool = False) -> str:
    """Snap a string to the nearest rail."""
    if not raw_strings:
        return eval_constants.INVALID
    snap_string = [s.lower() for s in raw_strings]
    n = len(snap_string)
    rails = list(set(rail.lower() for rail in rails))
    rails.sort(key=len, reverse=True)
    found_rails = set()
    for rail in rails:
        if rail in snap_string:
            found_rails.add(rail)
            snap_string.remove(rail)
        else:
            for s in snap_string:
                if rail in s:
                    found_rails.add(rail)
                    snap_string.remove(s)
                    break
    if len(found_rails) < 1:
        log_args(verbose, logging.ERROR, f"- Cannot snap {repr(raw_strings)} to rails: {rails}")
        return eval_constants.INVALID
    found_rails = list(found_rails)
    log_args(verbose, logging.INFO, f"- Snapped {repr(raw_strings)} to rails: {found_rails}")
    if len(found_rails) > 1:
        log_args(verbose, logging.WARN, "Currently only the first rail will be processed")
    return found_rails[0]


def parse_openai_function_call(raw_output: str) -> Tuple[List[str], Optional[str]]:
    """Parse the output of OpenAI function call."""
    try:
        function_arguments = json.loads(raw_output, strict=False)
        unrailed_label = function_arguments.get(eval_constants.RESPONSE, [])
        # llm can not guarantee the type of response data for custom prompt templates
        if isinstance(unrailed_label, str):
            unrailed_label = unrailed_label.split(',')
        explanation = function_arguments.get(eval_constants.EXPLANATION)
    except json.JSONDecodeError:
        unrailed_label = [raw_output]
        explanation = raw_output
    return unrailed_label, explanation


def openai_function_call_kwargs(rails: List[str], provide_explanation: bool) -> Dict[str, Any]:
    """Get keyword arguments for OpenAI model with function call for classification."""
    openai_function = _default_openai_function(rails, provide_explanation)
    return {
        eval_constants.TOOLS: [openai_function],
        eval_constants.TOOL_CHOICE: {
            "type": eval_constants.FUNCTION,
            eval_constants.FUNCTION: {
                "name": openai_function[eval_constants.FUNCTION]["name"]
            }
        },
    }


def _default_openai_function(
    rails: List[str],
    with_explanation: bool = False,
) -> Dict[str, Any]:
    """Default OpenAI function call for classification."""
    properties = {
        **({
            eval_constants.EXPLANATION: {
                "type": "string",
                "description": "Explanation of the reasoning for your response.",
            },
        } if with_explanation else {}),
        eval_constants.RESPONSE: {
            "type": "string",
            "description": "Your response.",
            "enum": rails
        },
    }
    required = [*([eval_constants.EXPLANATION] if with_explanation else []), eval_constants.RESPONSE]
    return {
        "type": eval_constants.FUNCTION,
        eval_constants.FUNCTION: {
            "name": eval_constants.FUNCTION_NAME,
            "description": "A function to record your response.",
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        }
    }


def calculate_retrieve_metrics(scores):
    retrieve_metrics = {}
    for retrieve_metric in eval_constants.RETRIEVE_METRICS:
        # support hit_rate, mrr, ndcg, precision
        metric_val = None
        if retrieve_metric == eval_constants.HIT_RATE:
            metric_val = RetrievalMetrics(scores).hit()
        elif retrieve_metric == eval_constants.MRR:
            metric_val = RetrievalMetrics(scores).reciprocal_rank()
        elif retrieve_metric == eval_constants.NDCG:
            metric_val = RetrievalMetrics(scores).ndcg()
        elif retrieve_metric == eval_constants.PRECISION:
            metric_val = RetrievalMetrics(scores).precision()
        retrieve_metrics.update({retrieve_metric: metric_val})
    logger.info(f'Calculate retrieve metrics: {retrieve_metrics}')
    return retrieve_metrics


def log_args(condition: bool, log_level=logging.INFO, *args: Any, **kwargs: Any) -> None:
    if condition:
        if log_level == logging.INFO:
            logger.info(*args, **kwargs)
        elif log_level == logging.ERROR:
            logger.error(*args, **kwargs)
        elif log_level == logging.WARNING:
            logger.warning(*args, **kwargs)


def validate_eval_results(eval_df: pd.DataFrame) -> str:
    err_msg = ''
    if eval_df is None:
        err_msg = 'Empty eval results'
        return err_msg
    if not isinstance(eval_df, pd.DataFrame):
        err_msg = 'Invalid eval results. Expected type: `pd.DataFrame`.'
        return err_msg
    if eval_constants.EVAL_ID not in eval_df:
        err_msg += f'Missing {eval_constants.EVAL_ID}. '
    if eval_constants.TRACE_ID not in eval_df:
        err_msg += f'Missing {eval_constants.TRACE_ID}. '
    if eval_constants.EVAL_RESULTS not in eval_df:
        err_msg += f'Missing {eval_constants.EVAL_RESULTS}. '
    return err_msg


def flat_eval_result(obj: object, include_doc_eval: bool, path: str = '') -> dict:
    d = {}
    if isinstance(obj, dict):
        for key, value in obj.items():
            if (key == eval_constants.LABEL or (not include_doc_eval and isinstance(value, list))):
                continue
            if key == eval_constants.SCORE:
                d.update({path: value})
                continue
            cat_path = f'{path}.{key}' if path and key else key
            if cat_path and eval_constants.DOC_SCORE not in cat_path:
                d.update(flat_eval_result(value, include_doc_eval, cat_path))
    elif path:
        d.update({path: obj})
    return d


def to_list(val: str) -> list:
    try:
        output_val = eval(val)
        if isinstance(output_val, list):
            return output_val
        raise ValueError(f'Invalid type: {type(output_val)}')
    except TypeError:
        raise ValueError(f'Failed converting {val} to list')
